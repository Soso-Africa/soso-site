# Headless Commerce staging starter

This is a server-side staging backend for validating a custom storefront against
JusticeSure Commerce API v1. It is intentionally separate from browser code:
the `jsk_…` Commerce key is read from the server process and is never returned
by any route.

For the production URL, complete endpoint map, authentication boundary and
launch criteria, see [`docs/headless-commerce-integration-guide.md`](../../docs/headless-commerce-integration-guide.md).

## What is included

JusticeSure maintainers: build distributable SOSO packages from the repository
root with `npm run commerce:handoff:generate -- --version <VERSION>
--release-date <YYYY-MM-DD> --replacement-notes "<WHAT THIS REPLACES AND WHY>"`.
See `scripts/README-commerce-handoff.md` in the source repository. Do not copy
an old ZIP after updating the contract; the builder regenerates and verifies it.

- `commerce-client.ts` — typed catalogue, delivery quote, order, hosted payment,
  and order-status calls with bounded rate-limit retries.
- `webhook-receiver.ts` — raw-body HMAC verification, five-minute replay window,
  authenticated envelope checks, and retry-safe processing.
- `postgres-webhook-store.ts` — durable leased event-ID claims and processing status.
- `example-server.ts` — runnable Express staging facade protected by a separate
  staging access token.

## Required server-side configuration

Set these only in the staging backend's secret manager. Do **not** use
`VITE_`, `NEXT_PUBLIC_`, `PUBLIC_`, or any other browser-exposed prefix.

| Variable | Purpose |
| --- | --- |
| `JUSTICESURE_COMMERCE_BASE_URL` | JusticeSure base URL. Production: `https://justicesure.ai/api/v1/commerce` |
| `JUSTICESURE_COMMERCE_API_KEY` | Dedicated staging `jsk_…` key with only the four Commerce scopes |
| `JUSTICESURE_COMMERCE_WEBHOOK_SECRET` | One-time signing secret from the webhook setup |
| `STOREFRONT_DATABASE_URL` | Staging storefront PostgreSQL database used for event deduplication |
| `STOREFRONT_STAGING_ACCESS_TOKEN` | Separate 16+ character gate for these staging-only routes |
| `PORT` | Optional; defaults to `4010` |

Required Commerce scopes:

1. `commerce:catalog:read`
2. `commerce:orders:write`
3. `commerce:payments:initiate`
4. `commerce:orders:read`

Start the sample:

```sh
npx tsx examples/headless-commerce-staging/example-server.ts
```

The sample permits HTTP only when the configured JusticeSure host is loopback
and `allowInsecureLoopback` is explicitly enabled in code. A normal staging
integration must use HTTPS.

## Generic integration readiness

Before running checkout:

- The business owner enables Online Store; the link is active, not suspended, and not archived. The staff POS expiry date does not close an enabled online store.
- Test products are active, sellable, online-enabled, and have deliberate stock
  at the chosen location.
- Pickup and/or delivery settings match the acceptance case.
- Paystack or Flutterwave sandbox settings are connected and ready for hosted checkout.
- The public HTTPS webhook URL subscribes to the required `commerce.*` events.

Create the server-only key in **Business → API Keys** (`/business/api-keys`) and
select only the four Commerce scopes below. Manage webhook subscriptions in
**Business → Integrations** (`/business/integrations`). The key belongs in the
custom storefront's backend secret manager; browser and mobile clients call that
backend, never JusticeSure directly.

## Acceptance matrix

Use a dedicated test business and unique idempotency keys. Reuse the **same**
key only when retrying the same logical operation.

| Case | Expected result |
| --- | --- |
| Published in-stock product | Appears with customer-safe price and availability |
| Unpublished or raw-material product | Does not appear |
| Sold-out tracked product | Reports unavailable; checkout cannot oversell |
| Product requiring a variant | Missing/foreign variant is rejected |
| Pickup order | Uses an owned, active, non-virtual location |
| Delivery order | Uses a fresh signed quote; fee is server-calculated |
| Repeated order request | Same order returned; no duplicate is created |
| Repeated payment-session request | Same reference/status returned; no duplicate session |
| Payment redirect only | Does not mark the order paid |
| Verified sandbox callback | Order status becomes paid |
| Tampered/stale webhook | Rejected before event storage or processing |
| Duplicate event ID | Returns success without reapplying side effects |
| Receiver failure then retry | First response is non-2xx; retry processes once |

## Webhook transaction rule

`PostgresCommerceWebhookStore` records the event before the handler runs,
returns non-2xx while another receiver still holds the claim, allows failed
events to be claimed again, and reclaims a processing claim after its five-minute
lease expires. The storefront's own side effects must also be idempotent by
`event.id`—ideally in the same database transaction. This protects the crash
window between applying a change and marking the delivery processed.

For production, replace `X-Staging-Access-Token` with the storefront's real
customer/session authorization. JusticeSure authenticates the merchant backend,
not the shopper: the custom backend must verify that its signed-in shopper may
read a requested order before calling JusticeSure. Do not copy staging API keys
or webhook secrets into production; create or rotate production credentials.

## Launch decisions

- **Platform availability:** JusticeSure can publish the Headless Commerce API
  for all developers once the production contract, authentication boundary,
  documentation, and shared-authority regression gates pass.
- **Integration acceptance:** any developer can run the matrix above against a
  dedicated test business and sandbox payment provider.
- **Merchant production certification:** only that merchant's own website waits
  for its production key, HTTPS webhook, payment-provider setup, and live smoke
  test. One merchant's unfinished integration does not block platform availability.