# SOSO / JusticeSure Commerce Gap Register v3.6 — 2026-09-13

**No deployment, merchant production readiness, provider approval, provider
transaction/refund evidence, or production release is claimed.** v3.6 describes
self-service account Test-mode onboarding and keeps external provider
qualification optional and separate.

| Area | Current truthful state | Closure / operating rule |
|---|---|---|
| Account Test onboarding | Limited browser observation completed on a disposable account; identifiers withheld | Start from the public developer page, authenticate, then use `/business/headless-commerce` → Test. The authorised account owner/developer provisions, revokes, or re-enables only its synthetic tenant. |
| Test credentials and callbacks | One-time self-service issuance; no values supplied | SOSO creates its own least-privilege `jsk_test_…` key and Test callback, copies each one-time value directly to its own backend secret manager, and verifies signed raw callbacks. Revoked scopes fail closed. Never use chat or source control to request/transfer them. |
| First-party Test acceptance | Limited synthetic browser/API observation and HTTP/client-test coverage completed | Browser/API observed: Test key issue/revoke/re-enable, callback lifecycle, default-pickup quote/order/session, simulated hosted payment success, API partial refund, UI remaining full refund, replay and over-remaining rejection. The explicit simulated Test-provider discovery route has valid schemas and its discovery → quote/order/session HTTP flow passed, but was not browser-observed. The newly added partial-refund UI field is client-tested but not browser-observed. Synthetic evidence is not provider evidence or production readiness. |
| External provider qualification | Optional and unexecuted | The existing external harness is reserved for a later separately authorised provider sandbox. It is not required for ordinary self-service Test onboarding and synthetic outcomes cannot substitute for provider approval. |
| Production migration | Production schema v319 / approved release pending | Create distinct live credentials/callbacks and complete merchant/provider/live URL review only after production schema v319 is approved and released. This package does not claim it is deployed. |
| Currency, FX and refund policy | Runtime contract candidate; operational facts unconfirmed | `chargeCurrency` is opt-in and defaults to NGN when omitted; `displayCurrency` is estimate-only. Preserve immutable original-charge/refund facts. Merchant/provider settlement and live currency readiness remain separate decisions. |

## Consolidated external inputs

Ordinary Test onboarding requires only SOSO's own JusticeSure account access,
authorised owner/developer role, SOSO-controlled HTTPS callback URL, and SOSO's
own backend secret manager. The Test tenant, one-time Test key, and callback
secret are self-served inside that account; no separate sandbox or credential is
requested through chat.

Only the optional provider-qualification path additionally requires separately
authorised provider-sandbox instructions and sanitized provider callback
evidence. Production later requires an approved release, merchant-owned live
credentials, provider readiness, and production URL review.