# SOSO ↔ JusticeSure Headless Commerce Integration Handoff

**Package:** SOSO JusticeSure Headless Commerce Handoff v3.6  
**Prepared:** 2026-09-13  
**Replacement notes:** Replaces v3.5; adds self-service account Test-mode onboarding while keeping external provider qualification separate.

Package version, prepared date, and replacement notes are inserted by the
handoff builder and recorded in `PACKAGE_MANIFEST.txt`.

**Target storefront:** `https://soso-africa-site.vercel.app/`  
**API contract:** `justicesure-headless-commerce-openapi-v1.json`

Do not use the blocked v3.0 OpenAPI file. Use the contract in this package,
including its complete success bodies for currency and payment-readiness
discovery, immutable quote creation/retrieval, authoritative order
creation/retrieval, and exact order replay.

## Start here

Give this entire ZIP to SOSO's Replit Agent and ask it to read this file and the
OpenAPI document before changing the storefront.

The OpenAPI document is the machine-readable source of truth for request and
response fields. This guide defines the required architecture, security,
recovery, and acceptance behavior.

The package contains no API keys, webhook secrets, payment credentials,
database credentials, or production access. SOSO must issue Test credentials and
configure Test callbacks in its own authenticated JusticeSure account, then put
the one-time values directly into its own backend secret manager. Do not request
or transfer keys, callback secrets, or sandbox access through chat or source
control.

## Copy/paste brief for SOSO's Replit Agent

> Integrate the existing SOSO Vercel storefront with JusticeSure Headless
> Commerce using this package. Preserve SOSO's current visual design and public
> URLs. Implement all JusticeSure calls server-side. Treat the included OpenAPI
> JSON as the request/response source of truth. Replace locally authoritative
> catalogue, price, stock, checkout, order, payment, and fulfilment state with
> JusticeSure data. Use immutable price quotes, durable idempotency keys,
> merchant-owned payment readiness discovery, hosted payment sessions, signed
> raw-body webhooks, and durable webhook leases/deduplication. Never expose a
> JusticeSure API key or webhook secret to browser JavaScript. Do not mark an
> order paid from a return URL or client assertion. Implement staging first and
> complete the acceptance matrix in this guide before production activation.
> Treat payment-attempt verify/reconcile as server-side recovery operations:
> use only JusticeSure-returned order/attempt IDs and never supply provider,
> amount, currency, account, or credential authority from SOSO.

## 1. Authority boundary

JusticeSure is authoritative for:

- enabled store profile, products, variants, visibility, prices, and stock;
- supported currencies and payment-method readiness;
- immutable payable price quotes and delivery/carrier calculations;
- order creation, totals, status, payment state, and fulfilment state;
- merchant-owned payment-account selection and hosted payment initialization;
- provider webhook verification and authoritative payment transitions.

SOSO owns:

- the storefront presentation and customer journey;
- its server-side JusticeSure adapter;
- customer session/cart convenience state before quoting;
- its local projection of JusticeSure order state for fast UI rendering;
- signed JusticeSure webhook receipt, durable processing, and local side
  effects.

SOSO must not:

- calculate an authoritative payable total in the browser;
- trust stale locally cached price or stock at checkout;
- send provider credentials to JusticeSure through the commerce API;
- select or override a private merchant payment-account identifier;
- mark an order paid, fulfilled, cancelled, or refunded locally;
- expose private carrier, connector, gateway, or authority metadata;
- reuse a key issued for another business or JusticeSure entity.

Each JusticeSure commerce API key is bound to exactly one business/entity. It
must never be shared between sibling companies or storefronts.

## 2. Server-side configuration

Configure placeholders like these through the SOSO project's secret manager:

```text
JUSTICESURE_COMMERCE_API_BASE_URL=https://justicesure.ai/api/v1/commerce
JUSTICESURE_COMMERCE_API_KEY=<one-time value issued in SOSO account Test tab>
JUSTICESURE_COMMERCE_WEBHOOK_SECRET=<one-time Test callback secret issued in SOSO account>
SOSO_PAYMENT_RETURN_URL=https://soso-africa-site.vercel.app/<payment-return-route>
SOSO_JUSTICESURE_WEBHOOK_URL=https://soso-africa-site.vercel.app/<webhook-route>
STOREFRONT_DATABASE_URL=<durable SOSO database>
```

Do not prefix secret variables with `NEXT_PUBLIC_`, `VITE_`, or any equivalent
browser-exposed convention.

Every Commerce API request must be made from SOSO's backend with:

```http
Authorization: Bearer jsk_...
Accept: application/json
Content-Type: application/json
```

Write requests that the OpenAPI contract marks idempotent also require:

```http
Idempotency-Key: <durable unique operation key>
```

## 3. Current endpoint map

Paths are relative to `/api/v1/commerce`.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/store` | Enabled public store profile |
| `GET` | `/categories` | Categories represented by visible products |
| `GET` | `/locations` | Customer-selectable selling locations |
| `GET` | `/currencies` | ISO-4217 display/capability metadata |
| `GET` | `/payment-methods` | Merchant-owned payment readiness and routes |
| `GET` | `/fulfillment-corridors` | Approved international carrier corridors |
| `GET` | `/products` | Visible, sellable products and variants |
| `GET` | `/products/{productId}` | One visible product |
| `POST` | `/delivery-quotes` | Signed delivery quote for legacy/domestic flow |
| `POST` | `/price-quotes` | Immutable authoritative payable cart quote |
| `GET` | `/price-quotes/{quoteId}` | Retrieve a still-valid immutable quote |
| `POST` | `/orders` | Idempotent order creation |
| `GET` | `/orders/{orderId}` | Authoritative order/payment/fulfilment status |
| `POST` | `/orders/{orderId}/payment-attempts/{attemptId}/verify` | Verify a bound payment attempt with its provider |
| `POST` | `/orders/{orderId}/payment-attempts/{attemptId}/reconcile` | Poll a bound payment attempt for recovery |
| `POST` | `/orders/{orderId}/payment-sessions` | Approved hosted payment initialization |

`POST /providers/webhooks/{provider}/{merchantAccountId}` is the
JusticeSure-owned raw provider webhook ingress. SOSO must not call it or proxy
provider events to it. Payment providers call that JusticeSure route directly.
SOSO receives normalized JusticeSure commerce events at SOSO's registered
webhook URL.

Use the OpenAPI document for scopes, filters, request bodies, response
discriminators, reason codes, and error bodies.

### v3.3 migration/addendum

v3.3 replaces v3.2 as the current handoff package because the v3.2 OpenAPI
document omitted two already-implemented public Commerce operations:
`POST /orders/{orderId}/payment-attempts/{attemptId}/verify` and
`POST /orders/{orderId}/payment-attempts/{attemptId}/reconcile`. Existing
catalogue, quote, order, hosted-session, and webhook paths are retained.
This addendum documents the public contract gap; it does not change payment
authority or make a client, redirect, provider reference, or reconciliation
request authoritative.

Consumers migrating from v3.2 must:

1. Replace the bundled OpenAPI and route allow-list with the v3.3 files.
2. Keep the existing `Authorization: Bearer jsk_...` server-only boundary and
   grant `commerce:payments:initiate` to the backend caller that invokes these
   routes.
3. Call verify/reconcile only with UUIDs already returned by JusticeSure and an
   exact order/attempt relationship. Send no request body and do not add
   provider, merchant-account, credential, amount, or currency fields.
4. Treat `status` and `paymentStatus` in the response as the only public
   lifecycle projection. Do not infer authority from the route name, provider
   redirects, browser callbacks, or a payment reference.
5. Handle `400`, `401`, `403`, `404`, `409`, `429`, `500`, and `502` using the
   documented error envelope. A missing attempt is not permission to create a
   replacement attempt; recover through the original order/attempt authority.
6. Preserve existing distinct durable idempotency keys for order creation and
   hosted payment-session creation. Verify/reconcile are status-recovery POSTs,
   not new payment operations and not substitutes for those idempotency claims.

JusticeSure loads the immutable payment attempt, intent, merchant account,
provider reference, expected amount, and currency from its own records. Verify
performs one provider verification; reconcile polls the same provider without
changing provider state. A result can update the attempt/order only after exact
provider, reference, amount, and currency checks. The response reports the
provider status observed and authoritative order payment status; a previously
succeeded attempt remains terminal if a later provider result is non-success.
The response intentionally does not expose the internal reconciliation terminal
flag, merchant account, connector, provider transaction, or raw provider
payload.

**Release status:** v3.3 is a source-contract and staging-handoff update. It
does not claim deployment, production certification, or external testing.
Deployment release remains pending.

### v3.6 self-service account Test mode (replaces v3.5 on 2026-09-13)

v3.6 replaces v3.5. **It does not claim a deployed release, merchant production
readiness, provider approval, provider payment/refund evidence, or production
certification.** It documents the account-owned Test-mode implementation
candidate and keeps external provider qualification separate from ordinary
onboarding.

From the public JusticeSure developer page, SOSO authenticates to its own
JusticeSure account, opens **Business → Headless Commerce**
(`/business/headless-commerce`), and selects the **Test** tab. An authorised
owner or invited Headless Commerce Developer can self-serve provision, revoke,
and re-enable its account/entity's synthetic Test tenant. It contains synthetic
catalogue/stock and first-party quote, order, hosted-session, simulated payment
lifecycle, and refund-helper flows; it never uses provider credentials or makes
provider requests.

Issue the least-privilege `jsk_test_…` key in the Test tab; its value is shown
once. Create a Test callback for SOSO's own HTTPS backend in that same account;
its signing secret is also shown only when created or rotated. Store both
server-side in SOSO's own secret manager, configure callbacks against SOSO's
account, and verify raw-body HMAC deliveries. Revoked Test keys/scopes must fail
closed. No key, callback secret, or tenant access is requested through chat,
placed in source control, or exposed to a browser.

Test end-to-end evidence can establish first-party Test onboarding, scoped-key
enforcement, synthetic quote/order/session lifecycle, simulated payment/refund
transition, and signed Test callback processing. It is **not** provider
approval/evidence, settlement evidence, a live charge/refund, merchant
production readiness, or a deployment claim. `chargeCurrency` remains explicit
opt-in (omission defaults to NGN); `displayCurrency` remains estimate-only.
The external provider acceptance harness remains an optional provider-
qualification path, not ordinary onboarding. It requires separately authorised
provider-sandbox evidence and cannot turn simulated results into provider
approval.

**v3.6 observed-evidence boundary:** a disposable authenticated account
browser/API check observed Test provisioning, Test key revoke/re-enable,
callback lifecycle, default-pickup quote/order/session, simulated hosted-payment
success, API partial refund, UI remaining full refund, refund replay, and
over-remaining rejection. No account, customer, order, key, secret, callback
payload, provider request, or provider evidence is recorded here. The newly
added partial-refund UI field is source-implemented only; its client test is
passed, but this handoff does not claim browser observation of that field. The
explicit simulated Test-provider discovery route and discovery → quote/order/
session HTTP flow are schema/HTTP-tested, not browser-observed; neither is
external provider readiness or approval.

**FX and refund operating rules:** customer charge money is the immutable
`originalCharge` snapshot, not a recalculation from a current display rate.
Display conversion remains an estimate with source, as-of, expiry and rounding
metadata. On quote expiry, rate staleness, changed price or disabled route,
requote and require customer review. Record quote FX direction/precision and
allocation policy before acceptance; reject missing/stale rates rather than
falling back to NGN. A full or partial refund must use the immutable successful
charge and returned provider outcome; it retains returned currency/amount and
cannot exceed the remaining amount. Refund acceptance requires the exact
`commerce.order.refunded` success envelope, original payment/attempt and refund
IDs, and `actualReturnedMoney` with matching currency, exponent and minor
units—not a recursively found amount. Provider settlement and NGN accounting stay
separate. Historic unlinked records remain `originalCharge.status: "unknown"`.

**Adapter migration:** preserve legacy numeric `*Kobo` NGN accounting fields for
existing consumers. New consumers read linked `originalCharge` integer-string
minor units, ISO currency and exponent; never relabel kobo values as foreign
charge money. Migrate forward-only, retain the quote/order/attempt/refund IDs,
and make an unknown historic original charge visible instead of fabricating a
conversion. Keep production migration and payment activation gated until
production schema v319/release is approved and the merchant completes its own
readiness decision; this handoff does not claim that release is deployed.

### v3.4 currency, refund, and evidence migration

v3.4 replaces v3.3 while retaining the `2025-01-01` webhook envelope and
legacy required lifecycle fields. It adds additive `originalCharge` projections
to quotes, order/payment lifecycle responses, and order/payment/refund webhook
data. It is an additive migration, not an
assertion that every historic record has recoverable foreign-currency evidence.

- `originalCharge.status: "known"` contains exact integer-string money with
  ISO-4217 currency, minor-unit exponent and linked public resource IDs.
- `originalCharge.status: "unknown"` is deliberate for legacy/unlinked or
  incomplete records. Do not replace it with a guessed NGN or display amount.
- Existing `*Kobo` / `currency: NGN` fields remain compatibility/accounting
  projections only. They are never evidence that a customer was charged NGN in
  a foreign-currency flow.
- Display FX remains an estimate. Persist its source, as-of timestamp, expiry,
  rounding and quote ID; it is not a charge or settlement guarantee.

The authorized business refund operation accepts a strict body containing only
an optional `amountMinor` decimal integer. Omit it for the legacy full-refund action. JusticeSure derives
currency, payment intent, provider and maximum amount from the immutable
attempt; it rejects zero/negative values, amounts above the remaining successful
refund balance, unsupported partial-refund accounts, and same-key retries with a
different amount. Use a new durable idempotency key for each distinct refund.
If a pending/unknown refund has no durably returned provider refund ID, the
response is explicitly `REFUND_OUTCOME_UNCERTAIN`, not a successful replay.
Where the provider ID is known, JusticeSure performs provider `getRefund`
reconciliation before returning a terminal replay. A verified early provider
webhook waits/retries until the ID binding exists; it is not permanently
quarantined merely because initialization and webhook delivery raced.

v3.4's discovery-only script is superseded by the v3.6 account Test-mode
guidance above. Synthetic Test outcomes cannot substitute for provider approval,
provider evidence, or a deployed production release.

## 4. Required storefront flow

### 4.1 Catalogue

Render catalogue/category/product pages from `GET /products` and
`GET /products/{productId}`. Respect only returned products and variants.

Catalogue responses may be cached for presentation, but checkout must always
obtain a new authoritative quote. A product displayed earlier can become
unavailable before checkout.

### 4.2 Discover capabilities

Before presenting checkout choices:

1. Read `/currencies` for display and capability metadata.
2. Read `/payment-methods` and offer only methods currently reported ready.
3. For international delivery, read `/fulfillment-corridors` and offer only
   approved, enabled corridors returned for the bound merchant.

Currency availability for display is not proof that a payment account can
charge that currency. Payment readiness is authoritative.

### 4.3 Create an immutable price quote

Send the current product/variant quantities and fulfilment facts to
`POST /price-quotes`.

For international delivery, send the complete structured address and package
facts required by the OpenAPI schema. JusticeSure freezes carrier rate,
validated address, customs/tax/duty facts, restricted-goods policy,
importer-of-record information, landed-cost disclosure, policy revision, and
policy hash into the quote.

JusticeSure persists a payable quote only after the exact merchant-owned
payment connector passes a side-effect-free readiness check. If it reports
`EXACT_PAYMENT_ACCOUNT_CONNECTOR_UNAVAILABLE`, show a recoverable checkout
message and do not create an order.

Persist the returned quote identifier and expiry. Never alter quoted money
locally. If JusticeSure reports `QUOTE_EXPIRED_REQUOTE_REQUIRED`, create a new
quote and ask the customer to review any changed amount.

### 4.4 Create the order

Create the order using the immutable quote contract required by the OpenAPI
document. Generate and durably persist an order idempotency key before the
first network attempt.

On timeout or ambiguous response, retry the exact request with the same key.
Do not create a second key merely because the first response was lost. Never
reuse the key for a changed cart, quote, customer, address, or order attempt.

Once a key is bound to an order, recover that same order. A changed payload
with the same key must be treated as a conflict, not as a new checkout.
Both a new order (`201`) and an exact replay (`200`) return the same
`OrderResponse` body. Read the required `Idempotency-Replayed` response header:
`false` identifies the first successful creation and `true` identifies an exact
replay. Never model a second or reduced replay body.

### 4.5 Initialize hosted payment

Use `POST /orders/{orderId}/payment-sessions` with a separate durable
idempotency key. The provider must be one reported ready by
`GET /payment-methods` and compatible with the frozen quote/order.

The current contract can return provider-discriminated hosted checkout
responses, including Paystack, Flutterwave, Stripe, PayPal, and Hydrogen when
the merchant has an approved, ready account.

Persist the JusticeSure order ID, provider, payment reference, checkout URL,
request body, and payment-session idempotency key before redirecting.

An exact replay must recover the same usable session. If the browser closes or
the response is lost, retry the exact session request with the same key.

Payment-session creation means **pending**, not paid.

### 4.6 Payment return

The browser return route is only customer navigation. It must:

1. display a pending/processing state;
2. query SOSO's backend, which queries `GET /orders/{orderId}`;
3. render only JusticeSure's authoritative payment/order state;
4. offer safe retry/status refresh where appropriate.

Never mark an order paid from query parameters, a provider JavaScript callback,
the existence of a payment reference, or the customer's redirect.

## 5. JusticeSure webhook receiver

Register a public HTTPS SOSO backend route. It must receive the raw request
bytes before JSON parsing.

JusticeSure sends:

```text
X-JusticeSure-Timestamp
X-JusticeSure-Event-Id
X-JusticeSure-Signature
```

Verify:

```text
HMAC-SHA256(
  webhookSecret,
  timestamp + "." + eventId + "." + rawRequestBody
)
```

Compare signatures in constant time after handling the documented `sha256=`
prefix. Reject malformed headers, invalid signatures, and stale timestamps;
five minutes is the recommended replay tolerance.

Use `examples/headless-commerce-staging/webhook-receiver.ts` as the verification
reference.

### Durable processing requirements

Do not use an in-memory set as the event store.

Before side effects, atomically claim the event ID in a durable database with a
processing lease. The processor must distinguish:

- completed: return success without repeating side effects;
- actively processing: return non-2xx so JusticeSure retries;
- expired lease or failed attempt: reclaim and continue;
- new event: claim and process.

Every local side effect must itself be idempotent by event ID. Mark completion
only after all required effects commit. If work remains unfinished, return
non-2xx. A JusticeSure retry carries the same event ID.

Use `postgres-webhook-store.ts` as the durable lease reference, then adapt its
SQL to SOSO's existing database conventions.

Expected normalized event families include catalogue, inventory, order,
payment, cancellation, refund, and fulfilment updates. Handle only event types
documented by the current contract/runtime and safely acknowledge supported
no-op events after recording them.

## 6. Error and retry rules

- `400`: fix the malformed request; do not retry unchanged.
- `401`: key missing, invalid, expired, or revoked; fail closed.
- `403`: key lacks scope or is outside its exact entity boundary; fail closed.
- `404`: do not substitute a locally invented resource.
- `409`: idempotency/payload or state conflict; recover the original operation
  or require a deliberate new customer attempt.
- `422`: catalogue, price, delivery, payment-readiness, quote, or stock
  condition is not currently fulfillable; display a safe user action.
- `429`: obey `Retry-After` and `RateLimit-*`; back off with jitter.
- `5xx` or timeout: retry safe reads; retry writes only with the exact persisted
  idempotency key and unchanged body.

Set bounded connection and response timeouts. Persist operation claims before
calling JusticeSure so a function restart or Vercel retry cannot create a
duplicate logical operation.

## 7. Vercel/storefront implementation notes

- JusticeSure calls belong in server routes/actions only.
- Webhook signature verification must use raw bytes, not re-serialized JSON.
- Use a durable database; Vercel function memory and filesystem are not durable.
- Keep the existing SOSO design and URLs unless a route is needed for payment
  return or webhook receipt.
- Do not cache authenticated responses in a public CDN.
- Store only the minimum customer/order projection SOSO needs; JusticeSure
  remains authoritative.
- Do not expose gateway account IDs, provider secrets, carrier credentials, or
  JusticeSure private authority metadata in browser responses or logs.
- Scrub authorization headers, signatures, secrets, and sensitive customer
  fields from logs.

## 8. Account Test acceptance matrix

SOSO's Agent should execute these in SOSO's account-owned Test tenant. They
establish first-party synthetic integration behavior only; actual provider
qualification and production certification are separate later decisions.

### Boundary and catalogue

- A missing, malformed, revoked, or wrong-entity key fails closed.
- API keys and webhook secrets are absent from browser bundles and network
  requests.
- Product/category pages render JusticeSure data.
- Hidden, archived, raw-material, unavailable, or foreign-entity items do not
  appear.
- A stale displayed price/stock is rejected or refreshed during quoting.

### Quotes, delivery, and payments

- Currency and payment choices come from discovery endpoints.
- Only ready merchant-owned payment methods are offered.
- Domestic pickup/delivery quoting works as configured.
- International delivery is offered only for returned approved corridors.
- Expired quotes force requoting and customer review.
- Missing exact payment connector fails before order/stock mutation.
- The same order request/key yields one order after timeout/retry.
- A changed order payload with the same key is rejected.
- The same payment-session request/key recovers one provider session.
- Session creation and return navigation leave payment pending until a signed
  simulated Test lifecycle outcome updates the synthetic order.

### Webhooks and recovery

- Invalid signature, stale timestamp, and malformed headers are rejected.
- Duplicate completed event IDs do not repeat side effects.
- Concurrent delivery cannot run the same event side effects twice.
- A non-2xx/failed attempt is visible and can be retried.
- An expired processing lease can be reclaimed after a simulated crash.
- Payment, refund, cancellation, and fulfilment UI follows authoritative
  JusticeSure status.
- Verify and reconcile use the exact returned order/attempt IDs, require the
  payment-initiate scope, send no authority fields in the body, and reject
  private-account data in the response projection.

### Test-account operations

- Rate limiting honors `Retry-After`.
- Secrets and sensitive headers are redacted from logs.
- SOSO self-serves its Test tenant, least-privilege Test key and Test callback
  from its authenticated `/business/headless-commerce` Test tab.
- Test callback URL and secret belong to SOSO's own account; the one-time values
  are stored only in SOSO's backend secret manager.
- Revoked Test credentials/scopes fail closed; re-enablement creates or restores
  only the account-owned synthetic Test capability.
- Production HTTPS webhook, payment-return URL, credentials and provider setup
  remain a separate migration pending an approved production release.

## 9. Account-owned onboarding and production actions

For Test mode, SOSO's authorised owner or invited Headless Commerce Developer:

1. starts at the public developer page, authenticates, then opens
   `/business/headless-commerce` → **Test**;
2. self-serves the account/entity's synthetic tenant and may revoke/re-enable it;
3. issues a least-privilege one-time Test key and places it in the SOSO backend
   secret manager;
4. registers SOSO's own Test HTTPS webhook and places its one-time signing secret
   in that same secret manager;
5. runs synthetic catalogue/quote/order/session/payment/refund and callback
   checks, including revoked-scope checks.

Provider approval, actual provider payment/refund evidence, carrier qualification,
and production migration are separate merchant decisions. The optional external
provider harness is only for that later qualification; it is not a prerequisite
to Test onboarding. No payment-provider key, JusticeSure production credential,
or Test secret should be handed to SOSO's Agent in this ZIP or through chat.

## 10. Package files

- `START_HERE.md` — this SOSO-specific implementation handoff.
- `justicesure-headless-commerce-openapi-v1.json` — current machine-readable
  contract.
- `examples/headless-commerce-staging/` — typed server client, webhook verifier,
  durable PostgreSQL lease store, sample server, and optional external provider
  qualification harness/configuration template.
- `SOSO_JUSTICESURE_COMMERCE_CAPABILITY_MATRIX_V3.6.json` — self-service Test
  coverage and separately pending provider/production assessments.
- `SOSO_JUSTICESURE_COMMERCE_ACCEPTANCE_RESULTS_V3.6.json` — sanitized limited
  first-party Test observation plus pending provider qualification/production
  classification.
- `SOSO_JUSTICESURE_COMMERCE_GAP_REGISTER_V3.6.md` — account Test onboarding,
  external qualification, and production-release blockers.
- `SHA256SUMS.txt` — integrity hashes for every packaged implementation file.
- `PACKAGE_MANIFEST.txt` — sorted archive file list and package metadata.

If prose and the OpenAPI document disagree on a field or response shape, stop
and follow the OpenAPI document. If a live staging response disagrees with the
OpenAPI contract, do not invent a fallback; capture the sanitized response and
request a JusticeSure contract correction.