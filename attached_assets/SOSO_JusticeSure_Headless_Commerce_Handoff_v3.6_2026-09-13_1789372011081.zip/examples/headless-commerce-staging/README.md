# Headless Commerce staging starter

This is a server-side staging backend for validating a custom storefront against
JusticeSure Commerce API v1. It is intentionally separate from browser code:
the `jsk_…` Commerce key is read from the server process and is never returned
by any route.

For the production URL, complete endpoint map, authentication boundary and
launch criteria, see [`docs/headless-commerce-integration-guide.md`](../../docs/headless-commerce-integration-guide.md).

## What is included

JusticeSure maintainers: build distributable SOSO packages from the repository
root with `npm run commerce:handoff:generate -- --version <VERSION>
--release-date <YYYY-MM-DD> --replacement-notes "<WHAT THIS REPLACES AND WHY>"`.
See `scripts/README-commerce-handoff.md` in the source repository. Do not copy
an old ZIP after updating the contract; the builder regenerates and verifies it.

- `commerce-client.ts` — typed catalogue, delivery quote, order, hosted payment,
  and order-status calls with bounded rate-limit retries.
- `webhook-receiver.ts` — raw-body HMAC verification, five-minute replay window,
  authenticated envelope checks, and retry-safe processing.
- `postgres-webhook-store.ts` — durable leased event-ID claims and processing status.
- `example-server.ts` — runnable Express staging facade protected by a separate
  staging access token.
- `soso-acceptance-harness.ts` — executable, release-bound isolated-sandbox
  acceptance runner. It runs the configured catalogue/variant → quote → order
  exact-replay/conflict → hosted-session exact-replay → signed-callback
  verification/recovery checks and produces sanitized linked results.
- `soso-acceptance-config.example.json` — credential-free template. Copy it to
  an untracked approved configuration and replace **every** operator-supplied
  identifier, route and matrix row; placeholders are deliberately not runnable.

## Required server-side configuration

Set these only in the staging backend's secret manager. Do **not** use
`VITE_`, `NEXT_PUBLIC_`, `PUBLIC_`, or any other browser-exposed prefix.

| Variable | Purpose |
| --- | --- |
| `JUSTICESURE_COMMERCE_BASE_URL` | JusticeSure base URL. Production: `https://justicesure.ai/api/v1/commerce` |
| `JUSTICESURE_COMMERCE_API_KEY` | One-time `jsk_test_…` key self-issued in SOSO's authenticated Account Test tab with only the four Commerce scopes |
| `JUSTICESURE_COMMERCE_WEBHOOK_SECRET` | One-time Test callback signing secret created in SOSO's own account |
| `STOREFRONT_DATABASE_URL` | Staging storefront PostgreSQL database used for event deduplication |
| `STOREFRONT_STAGING_ACCESS_TOKEN` | Separate 16+ character gate for these staging-only routes |
| `PORT` | Optional; defaults to `4010` |

Required Commerce scopes:

1. `commerce:catalog:read`
2. `commerce:orders:write`
3. `commerce:payments:initiate`
4. `commerce:orders:read`

Start the sample:

```sh
npx tsx examples/headless-commerce-staging/example-server.ts
```

The sample permits HTTP only when the configured JusticeSure host is loopback
and `allowInsecureLoopback` is explicitly enabled in code. A normal staging
integration must use HTTPS.

## Account Test end-to-end onboarding

Before running checkout:

- Start at the public JusticeSure developer page, authenticate to SOSO's own
  account, then use **Business → Headless Commerce** (`/business/headless-commerce`)
  → **Test**. Do not ask JusticeSure staff to send a separate sandbox, key, or
  webhook secret through chat.
- An authorised owner or invited Headless Commerce Developer provisions the
  account/entity's synthetic Test tenant. It can be revoked and re-enabled.
- Create the one-time least-privilege `jsk_test_…` key in that tab, then store it
  only in the custom storefront backend's secret manager.
- Create SOSO's own Test callback in that tab, copy its one-time/rotated signing
  secret to the same secret manager, and subscribe it to required `commerce.*`
  events. Browser and mobile clients call the SOSO backend, never JusticeSure
  directly.
- Test catalogue, stock, quote/order/session, payment lifecycle and refund helper
  outcomes are simulated first-party functionality. They never prove a payment
  provider approved the merchant, received a transaction, settled funds, or
  delivered provider evidence.

## Acceptance matrix

Use SOSO's account-owned synthetic Test tenant and unique idempotency keys.
Reuse the **same** key only when retrying the same logical operation.

| Case | Expected result |
| --- | --- |
| Published in-stock product | Appears with customer-safe price and availability |
| Unpublished or raw-material product | Does not appear |
| Sold-out tracked product | Reports unavailable; checkout cannot oversell |
| Product requiring a variant | Missing/foreign variant is rejected |
| Pickup order | Uses an owned, active, non-virtual location |
| Delivery order | Uses a fresh signed quote; fee is server-calculated |
| Repeated order request | Same order returned; no duplicate is created |
| Repeated payment-session request | Same reference/status returned; no duplicate session |
| Payment redirect only | Does not mark the order paid |
| Signed simulated Test callback | Synthetic order status becomes paid; this is not provider evidence |
| Tampered/stale webhook | Rejected before event storage or processing |
| Duplicate event ID | Returns success without reapplying side effects |
| Receiver failure then retry | First response is non-2xx; retry processes once |
| Partial refund | An eligible `full_and_partial` account accepts exact minor units, never exceeds the immutable remaining balance, and replays one matching key safely |
| Charge/display/settlement currency | Persist exact `originalCharge`; retain display FX as estimate only and do not relabel legacy kobo accounting fields |

## Optional external provider-qualification harness

**This is not ordinary Test onboarding.** The self-service Account Test flows
above use the synthetic tenant and simulated lifecycle/refund helper. This
separate runner is reserved for a later, explicitly approved external provider
qualification. It has not been executed by shipping this package and cannot
turn synthetic Test events into provider evidence.

1. An authorised provider-qualification owner approves a dedicated isolated
   provider sandbox and copies
   `soso-acceptance-config.example.json` outside source control. Fill one case
   for every approved merchant/location/variant/destination-country/currency/
   provider/method combination (NGN, GBP, USD, EUR, GHS, KES, ZAR, XOF and XAF
   must each be represented by a row or an explicit unsupported result).
   Each row must explicitly set both `displayCurrency` and `chargeCurrency`.
   The platform's runtime defaults omitted `chargeCurrency` to NGN; the harness
   forbids that omission so a display estimate cannot be misrepresented as a
   customer charge. `displayCurrency` alone remains estimate-only.
2. Configure only the named API-key and JusticeSure webhook-secret environment
   variables in the operator's secret manager, plus the two required sandbox
   attestations: `approvedBaseUrlEnv` must exactly equal `sandbox.baseUrl`, and
   `environmentAttestationEnv` must equal the approved attestation value. These
   must be independently provisioned values, not a self-asserted JSON boolean.
   The runner denies `justicesure.ai`, `www.justicesure.ai`, and
   `lexi-sure.replit.app` before its first request. Do not put credential values
   in the JSON files or results.
3. Run the pre-provider phase:

   ```sh
   npm run commerce:acceptance -- \
     --execute --config /secure/soso-acceptance.json \
     --state /secure/soso-acceptance-state.json \
     --output /secure/soso-acceptance-results.json
   ```

   The state file is a mode-0600, atomically replaced, nonsecret resumable
   record of only config/release binding, quote/order IDs, session reference,
   and completed replay checks. Reusing it prevents a second run from creating
   a fresh quote and then colliding with the original order idempotency key.
   The expected exit status is `2` (**incomplete**) until the operator has
   completed the approved provider-sandbox payment/refund scenarios and captured
   actual signed JusticeSure callbacks. The runner does not open checkout URLs,
   call a provider API, post an invented callback, call the provider ingress, or
   invoke merchant cancellation/refund actions.
4. The provider-qualification operator saves callback evidence outside source control. Each callback
   has Unix-seconds `timestamp`, `eventId`, `signature`, canonical `rawBodyBase64`, and
   `linkedResourceIds` (order, payment attempt and, for refunds, refund ID).
   It is grouped under `{ "packageVersion": "3.5", "cases": [...] }`; each case
   has its `caseId`, `payment`, optional `cancellation`, and `refunds`. A
   payment/refund callback is accepted only after HMAC-SHA256 verification of
   `timestamp + "." + eventId + "." + raw bytes` and after the declared resource
   IDs are found in the signed raw JSON. Refund evidence must specifically be a
   `commerce.order.refunded` success envelope with exact original
   payment/attempt/refund links and exact `actualReturnedMoney` currency,
   exponent and minor amount; a matching number elsewhere in a payload is not
   evidence. Refund callbacks must have unique event and refund IDs. If the
   cumulative returned amount is the full original charge, the final callback
   must be terminal `paymentStatus: "refunded"`; otherwise it must be
   `partially_refunded`. For rows that require it, attach explicit operator
   evidence that an exact refund retry returned the same refund ID and that an
   amount above the remaining balance was rejected with HTTP 409/422. Missing
   control evidence remains incomplete, not passed.
   A required cancellation is accepted only as an actual signed
   `commerce.order.cancelled` v2025-01-01 envelope whose `data.orderId` is the
   resumed order and whose `data.status` is exactly `cancelled`.
5. Rerun with `--evidence /secure/operator-callback-evidence.json`. This calls
   JusticeSure's bound verify/reconcile endpoints only after authentic callback
   evidence is supplied. A `0` status means every configured case passed. `2`
   means pending/missing operator evidence; `1` means failure. Publish only the
   sanitized results file after review.

The required release header is intentionally configurable and mandatory. A
missing/mismatched release identity fails the case, preventing evidence from
being joined across sandbox deployments. The results redact authorization,
secrets, signatures, raw callback bytes and common personal fields while
retaining statuses, resource IDs, money and correlation facts.

## Webhook transaction rule

`PostgresCommerceWebhookStore` records the event before the handler runs,
returns non-2xx while another receiver still holds the claim, allows failed
events to be claimed again, and reclaims a processing claim after its five-minute
lease expires. The storefront's own side effects must also be idempotent by
`event.id`—ideally in the same database transaction. This protects the crash
window between applying a change and marking the delivery processed.

For production, replace `X-Staging-Access-Token` with the storefront's real
customer/session authorization. JusticeSure authenticates the merchant backend,
not the shopper: the custom backend must verify that its signed-in shopper may
read a requested order before calling JusticeSure. Do not copy staging API keys
or webhook secrets into production; create or rotate production credentials.

## Launch decisions

- **Platform availability:** JusticeSure can publish the Headless Commerce API
  for all developers once the production contract, authentication boundary,
  documentation, and shared-authority regression gates pass.
- **Integration acceptance:** any developer can run the matrix above against a
  dedicated test business and sandbox payment provider.
- **Merchant production certification:** only that merchant's own website waits
  for its production key, HTTPS webhook, payment-provider setup, and live smoke
  test. One merchant's unfinished integration does not block platform availability.