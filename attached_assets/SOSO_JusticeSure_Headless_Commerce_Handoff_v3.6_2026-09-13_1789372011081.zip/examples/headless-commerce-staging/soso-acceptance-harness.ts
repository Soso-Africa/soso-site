/**
 * SOSO / JusticeSure isolated-sandbox acceptance runner.
 *
 * This runner calls JusticeSure Commerce only. It never follows a hosted URL,
 * calls a provider, posts a callback, or initiates a merchant refund. An
 * approved operator performs those actions in the provider sandbox and supplies
 * signed JusticeSure callback evidence for the second (recovery) run.
 */
import { createHmac, createHash, timingSafeEqual } from "node:crypto";
import { readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

type Json = Record<string, unknown>;
type CaseConfig = {
  id: string;
  country: string;
  displayCurrency: string;
  chargeCurrency: string;
  paymentMethod: string;
  provider: string;
  productId: string;
  variantId?: string;
  /** Obtained only from actual signed payment callback evidence after session creation. */
  paymentAttemptId?: string;
  quoteRequest: Json;
  orderRequest: Json;
  sessionRequest: Json;
  orderIdempotencyKey: string;
  sessionIdempotencyKey: string;
  conflictOrderRequest: Json;
  cancellation: { required: boolean };
  refund: { required: boolean; expectedAmountsMinor?: string[]; requireReplayAndOverRefundRejection: boolean };
};
export type AcceptanceConfig = {
  packageVersion: "3.5";
  sandbox: {
    baseUrl: string;
    apiKeyEnv: string;
    releaseId: string;
    releaseHeader: string;
    approvedBaseUrlEnv: string;
    environmentAttestationEnv: string;
    environmentAttestationValue: string;
    approvedBy: string;
    contractVersion: string;
  };
  merchant: { businessId: string; locationId: string; country: string };
  callbackEvidence: { secretEnv: string };
  cases: CaseConfig[];
};

type CallbackEvidence = {
  timestamp: string;
  eventId: string;
  signature: string;
  rawBodyBase64: string;
  linkedResourceIds: { orderId: string; paymentAttemptId?: string; refundId?: string };
};
type OperatorEvidence = {
  packageVersion: "3.5";
  cases: Array<{
    caseId: string;
    payment?: { providerReference: string; callback: CallbackEvidence };
    cancellation?: { callback: CallbackEvidence };
    refunds?: Array<{ amountMinor: string; callback: CallbackEvidence }>;
    refundControls?: {
      exactReplay: { refundId: string; idempotencyKey: string; outcome: "same_refund_returned" };
      overRefundRejection: { attemptedAmountMinor: string; httpStatus: 409 | 422; errorCode: string };
    };
  }>;
};
export type RunState = {
  packageVersion: "3.5";
  configDigest: string;
  baseUrl: string;
  releaseId: string;
  cases: Record<string, {
    quoteId?: string; orderId?: string; sessionReference?: string; paymentAttemptId?: string; chargeFingerprint?: string;
    orderReplayProved?: boolean; orderConflictProved?: boolean;
  }>;
};

const secretKey = /(authorization|api.?key|secret|signature|token|password|cookie|rawbody)/i;
const idKey = /^[A-Za-z0-9_.:-]{8,64}$/;
const providerNames = new Set(["paystack", "flutterwave", "stripe", "paypal", "hydrogen"]);
const methodNames = new Set(["card", "bank_transfer", "wallet", "paypal", "virtual_account"]);

function isObject(value: unknown): value is Json {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}
function getString(value: unknown, label: string): string {
  assert(typeof value === "string" && value.trim(), `${label} must be a nonempty string.`);
  return value;
}
function getObject(value: unknown, label: string): Json {
  assert(isObject(value), `${label} must be an object.`);
  return value;
}
function hasResource(value: unknown, wanted: string): boolean {
  if (value === wanted) return true;
  if (Array.isArray(value)) return value.some((item) => hasResource(item, wanted));
  return isObject(value) && Object.values(value).some((item) => hasResource(item, wanted));
}

/** Validate all safety-critical fields before reading credentials or sending a request. */
export function validateAcceptanceConfig(value: unknown): AcceptanceConfig {
  const config = getObject(value, "Acceptance configuration");
  assert(config.packageVersion === "3.5", "packageVersion must be exactly 3.5.");
  const sandbox = getObject(config.sandbox, "sandbox");
  const baseUrl = getString(sandbox.baseUrl, "sandbox.baseUrl");
  let url: URL;
  try { url = new URL(baseUrl); } catch { throw new Error("sandbox.baseUrl must be an absolute HTTPS URL."); }
  assert(url.protocol === "https:" && !url.username && !url.password && !url.search && !url.hash,
    "sandbox.baseUrl must be a credential-free HTTPS URL without query or fragment.");
  assert(!new Set(["justicesure.ai", "www.justicesure.ai", "lexi-sure.replit.app"]).has(url.hostname.toLowerCase()),
    "sandbox.baseUrl is a known production URL; acceptance requires an approved isolated sandbox.");
  for (const field of ["apiKeyEnv", "releaseId", "releaseHeader", "approvedBy", "contractVersion", "approvedBaseUrlEnv", "environmentAttestationEnv", "environmentAttestationValue"]) getString(sandbox[field], `sandbox.${field}`);
  const merchant = getObject(config.merchant, "merchant");
  for (const field of ["businessId", "locationId", "country"]) getString(merchant[field], `merchant.${field}`);
  const callbackEvidence = getObject(config.callbackEvidence, "callbackEvidence");
  getString(callbackEvidence.secretEnv, "callbackEvidence.secretEnv");
  assert(!("apiKey" in sandbox) && !("secret" in callbackEvidence),
    "Credentials belong in named environment variables, never in the config file.");
  assert(Array.isArray(config.cases) && config.cases.length > 0, "cases must contain at least one approved matrix case.");
  const seen = new Set<string>();
  for (const rawCase of config.cases) {
    const entry = getObject(rawCase, "case");
    const id = getString(entry.id, "case.id");
    assert(!seen.has(id), `Duplicate case.id: ${id}`); seen.add(id);
    for (const field of ["country", "displayCurrency", "chargeCurrency", "paymentMethod", "provider", "productId", "orderIdempotencyKey", "sessionIdempotencyKey"]) {
      getString(entry[field], `case ${id}.${field}`);
    }
    assert(/^[A-Z]{2}$/.test(entry.country as string), `case ${id}.country must be ISO alpha-2 uppercase.`);
    assert(/^[A-Z]{3}$/.test(entry.displayCurrency as string) && /^[A-Z]{3}$/.test(entry.chargeCurrency as string),
      `case ${id} displayCurrency and chargeCurrency must be ISO-4217 uppercase.`);
    assert(methodNames.has(entry.paymentMethod as string), `case ${id}.paymentMethod is not an approved contract method.`);
    assert(providerNames.has(entry.provider as string), `case ${id}.provider is not an approved contract provider.`);
    assert(idKey.test(entry.orderIdempotencyKey as string) && idKey.test(entry.sessionIdempotencyKey as string),
      `case ${id} idempotency keys must be 8–64 safe characters.`);
    assert(entry.orderIdempotencyKey !== entry.sessionIdempotencyKey, `case ${id} needs separate order and session idempotency keys.`);
    for (const field of ["quoteRequest", "orderRequest", "sessionRequest", "conflictOrderRequest"]) getObject(entry[field], `case ${id}.${field}`);
    const quote = entry.quoteRequest as Json;
    assert(quote.displayCurrency === entry.displayCurrency && quote.chargeCurrency === entry.chargeCurrency && quote.customerCountry === entry.country
      && quote.provider === entry.provider && quote.paymentMethod === entry.paymentMethod,
    `case ${id}.quoteRequest must explicitly match its country/currency/provider/method matrix row.`);
    const session = entry.sessionRequest as Json;
    assert(session.provider === entry.provider, `case ${id}.sessionRequest.provider must match case.provider.`);
    for (const operation of ["cancellation", "refund"]) {
      assert(isObject(entry[operation]) && typeof (entry[operation] as Json).required === "boolean",
        `case ${id}.${operation}.required must be boolean.`);
    }
    const expected = (entry.refund as Json).expectedAmountsMinor;
    if (expected !== undefined) {
      assert(Array.isArray(expected) && expected.every((amount) => typeof amount === "string" && /^[1-9]\d*$/.test(amount)),
        `case ${id}.refund.expectedAmountsMinor must contain positive integer strings.`);
    }
    assert(typeof (entry.refund as Json).requireReplayAndOverRefundRejection === "boolean",
      `case ${id}.refund.requireReplayAndOverRefundRejection must be boolean.`);
  }
  return config as AcceptanceConfig;
}

/** Checks a captured raw JusticeSure callback without replaying it to any endpoint. */
export function verifySignedCallback(evidence: CallbackEvidence, secret: string): Json {
  assert(/^[1-9]\d*$/.test(evidence.timestamp), "Callback timestamp must be Unix seconds.");
  assert(evidence.eventId.length >= 8, "Callback eventId is malformed.");
  assert(typeof evidence.rawBodyBase64 === "string" && evidence.rawBodyBase64.length > 0, "Callback rawBodyBase64 is required.");
  const raw = Buffer.from(evidence.rawBodyBase64, "base64");
  assert(raw.length > 1 && raw.toString("base64") === evidence.rawBodyBase64, "Callback rawBodyBase64 is not canonical base64.");
  const supplied = evidence.signature.replace(/^sha256=/i, "");
  assert(/^[a-f0-9]{64}$/i.test(supplied), "Callback signature must be sha256 hex.");
  const expected = createHmac("sha256", secret).update(`${evidence.timestamp}.${evidence.eventId}.`).update(raw).digest("hex");
  assert(timingSafeEqual(Buffer.from(supplied, "hex"), Buffer.from(expected, "hex")), "Callback signature does not verify.");
  let body: unknown;
  try { body = JSON.parse(raw.toString("utf8")); } catch { throw new Error("Callback raw body is not JSON evidence."); }
  assert(isObject(body), "Callback payload must be a JSON object.");
  assert(body.id === evidence.eventId, "Callback eventId header evidence does not match the signed envelope ID.");
  assert(hasResource(body, evidence.linkedResourceIds.orderId), "Signed callback does not contain its declared order ID.");
  if (evidence.linkedResourceIds.paymentAttemptId) {
    assert(hasResource(body, evidence.linkedResourceIds.paymentAttemptId), "Signed callback does not contain its declared payment-attempt ID.");
  }
  if (evidence.linkedResourceIds.refundId) {
    assert(hasResource(body, evidence.linkedResourceIds.refundId), "Signed callback does not contain its declared refund ID.");
  }
  return body;
}

export function assertRuntimeSandboxAttestation(config: AcceptanceConfig, env: Record<string, string | undefined> = process.env): void {
  const sandbox = config.sandbox;
  assert(env[sandbox.approvedBaseUrlEnv] === sandbox.baseUrl,
    `Approved sandbox URL attestation ${sandbox.approvedBaseUrlEnv} does not exactly match sandbox.baseUrl.`);
  assert(env[sandbox.environmentAttestationEnv] === sandbox.environmentAttestationValue,
    `Isolated environment attestation ${sandbox.environmentAttestationEnv} is missing or does not match the approved value.`);
}

/** Keep correlation IDs and money/status facts; remove credentials, signatures, raw callback bodies and personal fields. */
export function sanitizeForResults(value: unknown, key = ""): unknown {
  if (secretKey.test(key)) return "[REDACTED]";
  if (Array.isArray(value)) return value.map((item) => sanitizeForResults(item));
  if (!isObject(value)) return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([name]) => !/^(email|phone|name|address|recipient)/i.test(name))
    .map(([name, item]) => [name, sanitizeForResults(item, name)]));
}

function jsonDigest(value: unknown): string {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}
export async function loadRunState(statePath: string, config: AcceptanceConfig): Promise<RunState> {
  const fresh = (): RunState => ({
    packageVersion: "3.5", configDigest: jsonDigest(config), baseUrl: config.sandbox.baseUrl,
    releaseId: config.sandbox.releaseId, cases: {},
  });
  try {
    const parsed = JSON.parse(await readFile(statePath, "utf8")) as unknown;
    assert(isObject(parsed) && parsed.packageVersion === "3.5" && parsed.configDigest === jsonDigest(config)
      && parsed.baseUrl === config.sandbox.baseUrl && parsed.releaseId === config.sandbox.releaseId && isObject(parsed.cases),
    "Resume state does not belong to this exact approved config, sandbox URL, and release.");
    return parsed as RunState;
  } catch (error: any) {
    if (error?.code === "ENOENT") return fresh();
    throw error;
  }
}
export async function saveRunState(statePath: string, state: RunState): Promise<void> {
  const temporary = `${statePath}.tmp-${process.pid}`;
  await writeFile(temporary, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
  await rename(temporary, statePath);
}
function getData(body: Json): Json {
  return isObject(body.data) ? body.data : body;
}
function requireId(body: Json, label: string): string {
  return getString(getData(body).id, `${label}.data.id`);
}
function originalChargeFingerprint(value: unknown, currency: string, label: string): string {
  const charge = getObject(value, `${label}.originalCharge`);
  assert(charge.status === "known" && charge.currency === currency && Number.isInteger(charge.minorUnitExponent),
    `${label} does not expose a known original charge in the configured currency.`);
  const components = isObject(charge.components) ? charge.components : undefined;
  const money = components && isObject(components.total) ? components.total : charge.amount;
  const amount = getObject(money, `${label}.originalCharge total`);
  const minor = getString(amount.amountMinor, `${label}.originalCharge total.amountMinor`);
  assert(/^\d+$/.test(minor) && amount.currency === currency && amount.minorUnitExponent === charge.minorUnitExponent,
    `${label} original-charge money is not exact, currency-owned minor-unit money.`);
  return `${currency}:${charge.minorUnitExponent}:${minor}`;
}
function requireEventData(body: Json, event: string, label: string): Json {
  assert(body.event === event && body.apiVersion === "2025-01-01", `${label} must be a ${event} v2025-01-01 envelope.`);
  return getObject(body.data, `${label}.data`);
}
export function requireSucceededLifecycle(body: Json, attemptId: string, fingerprint: string, currency: string, label: string): void {
  const data = getData(body);
  assert(data.attemptId === attemptId && data.status === "succeeded" && data.paymentStatus === "paid",
    `${label} must authoritatively report this attempt as succeeded and the order as paid.`);
  assert(originalChargeFingerprint(data.originalCharge, currency, label) === fingerprint,
    `${label} did not preserve the immutable original charge.`);
}
export function requireRefundEvidence(body: Json, input: {
  orderId: string; attemptId: string; refundId: string; amountMinor: string; currency: string; fingerprint: string;
}): Json {
  const data = requireEventData(body, "commerce.order.refunded", "Refund callback");
  assert(data.orderId === input.orderId && data.paymentAttemptId === input.attemptId && data.refundId === input.refundId,
    "Refund callback does not link the exact order, original payment attempt, and refund.");
  assert(data.paymentStatus === "partially_refunded" || data.paymentStatus === "refunded",
    "Refund callback does not report a successful authoritative refund state.");
  assert(originalChargeFingerprint(data.originalCharge, input.currency, "Refund callback") === input.fingerprint,
    "Refund callback original charge does not link the immutable original payment.");
  const resources = getObject(getObject(data.originalCharge, "Refund callback.originalCharge").resources, "Refund callback.originalCharge.resources");
  assert(resources.orderId === input.orderId && resources.paymentAttemptId === input.attemptId
    && typeof resources.paymentIntentId === "string" && data.paymentIntentId === resources.paymentIntentId,
  "Refund callback original-payment resource links are incomplete or inconsistent.");
  const actual = getObject(data.actualReturnedMoney, "Refund callback.actualReturnedMoney");
  assert(actual.status !== "unknown" && actual.amountMinor === input.amountMinor && actual.currency === input.currency
    && Number.isInteger(actual.minorUnitExponent) && actual.minorUnitExponent === Number(input.fingerprint.split(":")[1]),
  "Refund callback actualReturnedMoney must be exact returned currency, exponent, and configured minor amount.");
  return data;
}
export function requireCancellationEvidence(body: Json, orderId: string): void {
  const data = requireEventData(body, "commerce.order.cancelled", "Cancellation callback");
  assert(data.orderId === orderId && data.status === "cancelled",
    "Cancellation callback must link the exact order and report status cancelled.");
}

type HttpResult = { status: number; headers: Headers; body: Json };
async function commerceRequest(baseUrl: string, apiKey: string, releaseHeader: string, releaseId: string, pathname: string, init: RequestInit = {}): Promise<HttpResult> {
  const response = await fetch(`${baseUrl.replace(/\/$/, "")}${pathname}`, {
    ...init,
    headers: { Authorization: `Bearer ${apiKey}`, Accept: "application/json", ...(init.headers ?? {}) },
  });
  const observedRelease = response.headers.get(releaseHeader);
  if (observedRelease !== releaseId) throw new Error(`Release identity mismatch on ${pathname}: expected ${releaseHeader}=${releaseId}; observed ${observedRelease ?? "missing"}.`);
  const text = await response.text();
  let body: unknown = {};
  try { body = text ? JSON.parse(text) : {}; } catch { throw new Error(`${pathname} returned non-JSON evidence.`); }
  assert(isObject(body), `${pathname} returned a non-object JSON response.`);
  return { status: response.status, headers: response.headers, body };
}
function pushCase(results: Json, id: string, check: string, status: "passed" | "failed" | "pending", detail?: unknown) {
  const cases = results.cases as Json[];
  cases.push({ id, check, status, ...(detail === undefined ? {} : { detail: sanitizeForResults(detail) }) });
}

export async function runAcceptance(config: AcceptanceConfig, evidence: OperatorEvidence | undefined, statePath: string): Promise<Json> {
  // This guard runs before even a discovery GET, and therefore before all mutations.
  assertRuntimeSandboxAttestation(config);
  const state = await loadRunState(statePath, config);
  const persist = () => saveRunState(statePath, state);
  const apiKey = process.env[config.sandbox.apiKeyEnv];
  assert(apiKey, `Missing sandbox API key environment variable: ${config.sandbox.apiKeyEnv}.`);
  const secret = evidence ? process.env[config.callbackEvidence.secretEnv] : undefined;
  if (evidence) assert(secret, `Missing callback signing-secret environment variable: ${config.callbackEvidence.secretEnv}.`);
  const results: Json = {
    packageVersion: "3.5", status: "incomplete", executedAt: new Date().toISOString(),
    sandbox: { releaseId: config.sandbox.releaseId, contractVersion: config.sandbox.contractVersion, approvedBy: config.sandbox.approvedBy },
    merchant: sanitizeForResults(config.merchant), cases: [] as Json[],
    safety: "No provider URL, provider API, JusticeSure provider-webhook ingress, merchant cancellation, or merchant refund endpoint is called by this harness.",
  };
  for (const endpoint of ["/store", "/locations", "/currencies", "/payment-methods", "/products"]) {
    try {
      const answer = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, endpoint);
      if (endpoint === "/locations") {
        assert(answer.status === 200 && hasResource(answer.body, config.merchant.locationId),
          "Configured isolated merchant location was not returned by /locations.");
      }
      pushCase(results, "environment", endpoint, answer.status === 200 ? "passed" : "failed", { httpStatus: answer.status, body: answer.body });
    } catch (error) { pushCase(results, "environment", endpoint, "failed", error instanceof Error ? error.message : String(error)); }
  }
  if ((results.cases as Json[]).some((item) => item.status === "failed")) {
    results.status = "failed";
    results.safety = "No mutation was attempted because sandbox/release discovery failed.";
    return results;
  }
  for (const entry of config.cases) {
    const prefix = entry.id;
    const persisted = state.cases[prefix] ?? (state.cases[prefix] = {});
    let orderId: string | undefined;
    let chargeFingerprint = persisted.chargeFingerprint ?? "";
    try {
      if (persisted.orderId && persisted.sessionReference && chargeFingerprint) {
        const resumed = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId,
          `/orders/${encodeURIComponent(persisted.orderId)}`);
        assert(resumed.status === 200 && requireId(resumed.body, "resumed order") === persisted.orderId,
          "Resumed order is no longer retrievable from the bound sandbox.");
        assert(originalChargeFingerprint(getData(resumed.body).originalCharge, entry.chargeCurrency, "resumed order") === chargeFingerprint,
          "Resumed order original charge differs from persisted acceptance state.");
        orderId = persisted.orderId;
        pushCase(results, prefix, "resumed-order-and-session", "passed", { orderId, sessionReference: persisted.sessionReference });
      } else {
      const product = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, `/products/${encodeURIComponent(entry.productId)}`);
      assert(product.status === 200 && hasResource(product.body, entry.productId), "Configured product was not returned by the catalogue.");
      if (entry.variantId) assert(hasResource(product.body, entry.variantId), "Configured variant was not returned by the product.");
      pushCase(results, prefix, "catalogue-variant", product.status === 200 ? "passed" : "failed", { httpStatus: product.status, body: product.body });
      const quote = persisted.quoteId
        ? await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, `/price-quotes/${encodeURIComponent(persisted.quoteId)}`)
        : await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, "/price-quotes", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(entry.quoteRequest),
        });
      assert(quote.status === (persisted.quoteId ? 200 : 201), `price quote ${persisted.quoteId ? "retrieval" : "creation"} returned HTTP ${quote.status}`);
      const quoteId = requireId(quote.body, "price quote");
      const quoteData = getData(quote.body);
      assert(quoteData.displayCurrency === entry.displayCurrency && quoteData.payment && isObject(quoteData.payment)
        && quoteData.payment.chargeCurrency === entry.chargeCurrency, "Quote did not preserve configured display/charge currency.");
      chargeFingerprint = originalChargeFingerprint(quoteData.originalCharge, entry.chargeCurrency, "quote");
      if (!persisted.quoteId) {
        persisted.quoteId = quoteId;
        persisted.chargeFingerprint = chargeFingerprint;
        await persist();
      }
      pushCase(results, prefix, "quote-money", "passed", { quoteId, originalCharge: quoteData.originalCharge, payment: quoteData.payment });
      const orderRequest = { ...entry.orderRequest, quoteId };
      const order = persisted.orderId
        ? await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, `/orders/${encodeURIComponent(persisted.orderId)}`)
        : await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, "/orders", {
          method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": entry.orderIdempotencyKey }, body: JSON.stringify(orderRequest),
        });
      assert(order.status === (persisted.orderId ? 200 : 201) || (!persisted.orderId && order.status === 200 && order.headers.get("Idempotency-Replayed") === "true"),
        `order ${persisted.orderId ? "retrieval" : "creation"} returned HTTP ${order.status}`);
      orderId = requireId(order.body, "order");
      if (persisted.orderId) assert(orderId === persisted.orderId, "Resumed order retrieval returned another order.");
      else { persisted.orderId = orderId; await persist(); }
      assert(originalChargeFingerprint(getData(order.body).originalCharge, entry.chargeCurrency, "order") === chargeFingerprint,
        "Order original charge differs from its immutable quote.");
      if (!persisted.orderReplayProved) {
        const replay = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, "/orders", {
          method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": entry.orderIdempotencyKey }, body: JSON.stringify(orderRequest),
        });
        assert(replay.status === 200 && replay.headers.get("Idempotency-Replayed") === "true" && requireId(replay.body, "order replay") === orderId,
          "Exact order replay did not return the original order with Idempotency-Replayed: true.");
        persisted.orderReplayProved = true; await persist();
        pushCase(results, prefix, "order-replay", "passed", { orderId, originalCharge: getData(order.body).originalCharge });
      } else pushCase(results, prefix, "order-replay", "passed", { orderId, resumed: true });
      if (!persisted.orderConflictProved) {
        const conflict = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, "/orders", {
          method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": entry.orderIdempotencyKey }, body: JSON.stringify({ ...entry.conflictOrderRequest, quoteId }),
        });
        assert(conflict.status === 409, `Changed-body order conflict returned HTTP ${conflict.status}, expected 409.`);
        persisted.orderConflictProved = true; await persist();
        pushCase(results, prefix, "order-conflict", "passed", { httpStatus: conflict.status, body: conflict.body });
      } else pushCase(results, prefix, "order-conflict", "passed", { orderId, resumed: true });
      const session = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, `/orders/${encodeURIComponent(orderId)}/payment-sessions`, {
        method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": entry.sessionIdempotencyKey }, body: JSON.stringify(entry.sessionRequest),
      });
      assert(session.status === 200, `payment session returned HTTP ${session.status}`);
      const sessionReplay = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId, `/orders/${encodeURIComponent(orderId)}/payment-sessions`, {
        method: "POST", headers: { "Content-Type": "application/json", "Idempotency-Key": entry.sessionIdempotencyKey }, body: JSON.stringify(entry.sessionRequest),
      });
      assert(sessionReplay.status === 200 && getData(session.body).reference === getData(sessionReplay.body).reference,
        "Payment-session replay did not preserve the provider reference.");
      assert(originalChargeFingerprint(getData(session.body).originalCharge, entry.chargeCurrency, "payment session") === chargeFingerprint,
        "Hosted session original charge differs from the immutable quote.");
      persisted.sessionReference = getString(getData(session.body).reference, "payment session reference");
      await persist();
      pushCase(results, prefix, "hosted-session-replay", "passed", { orderId, session: getData(session.body) });
      }
    } catch (error) {
      pushCase(results, prefix, "pre-provider-lifecycle", "failed", error instanceof Error ? error.message : String(error));
      continue;
    }
    const supplied = evidence?.cases.find((item) => item.caseId === entry.id);
    if (!supplied?.payment) { pushCase(results, prefix, "operator-payment-and-signed-callback", "pending"); continue; }
    try {
      const paymentBody = verifySignedCallback(supplied.payment.callback, secret!);
      const paymentData = requireEventData(paymentBody, "commerce.payment.updated", "Payment callback");
      const paymentAttemptId = getString(supplied.payment.callback.linkedResourceIds.paymentAttemptId, "Payment callback evidence paymentAttemptId");
      assert(supplied.payment.callback.linkedResourceIds.orderId === orderId, "Payment callback evidence references another order.");
      assert(!persisted.paymentAttemptId || persisted.paymentAttemptId === paymentAttemptId,
        "Payment callback evidence references a different resumed payment attempt.");
      persisted.paymentAttemptId = paymentAttemptId; await persist();
      assert(paymentData.orderId === orderId && paymentData.attemptId === paymentAttemptId
        && paymentData.provider === entry.provider && paymentData.paymentStatus === "paid",
      "Payment callback does not authoritatively link this paid payment attempt.");
      assert(originalChargeFingerprint(paymentData.originalCharge, entry.chargeCurrency, "Payment callback") === chargeFingerprint,
        "Payment callback original charge differs from the immutable quote.");
      const verified = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId,
        `/orders/${encodeURIComponent(orderId!)}/payment-attempts/${encodeURIComponent(paymentAttemptId)}/verify`, { method: "POST" });
      const recovered = await commerceRequest(config.sandbox.baseUrl, apiKey, config.sandbox.releaseHeader, config.sandbox.releaseId,
        `/orders/${encodeURIComponent(orderId!)}/payment-attempts/${encodeURIComponent(paymentAttemptId)}/reconcile`, { method: "POST" });
      assert(verified.status === 200 && recovered.status === 200, "Verify/recovery did not return 200.");
      requireSucceededLifecycle(verified.body, paymentAttemptId, chargeFingerprint, entry.chargeCurrency, "Verify response");
      requireSucceededLifecycle(recovered.body, paymentAttemptId, chargeFingerprint, entry.chargeCurrency, "Recovery response");
      pushCase(results, prefix, "signed-payment-callback-verify-recovery", "passed", { orderId, paymentCallback: paymentBody, verify: verified.body, reconcile: recovered.body });
    } catch (error) { pushCase(results, prefix, "signed-payment-callback-verify-recovery", "failed", error instanceof Error ? error.message : String(error)); continue; }
    if (entry.cancellation.required) {
      if (!supplied.cancellation) { pushCase(results, prefix, "operator-cancellation-and-signed-callback", "pending"); }
      else {
        try {
          const body = verifySignedCallback(supplied.cancellation.callback, secret!);
          assert(supplied.cancellation.callback.linkedResourceIds.orderId === orderId, "Cancellation callback evidence references another order.");
          requireCancellationEvidence(body, orderId!);
          pushCase(results, prefix, "operator-cancellation-and-signed-callback", "passed", { orderId, callback: body });
        } catch (error) { pushCase(results, prefix, "operator-cancellation-and-signed-callback", "failed", error instanceof Error ? error.message : String(error)); }
      }
    }
    if (!entry.refund.required) { pushCase(results, prefix, "operator-refund", "passed", "Not applicable by approved matrix configuration."); continue; }
    if (!supplied.refunds?.length) { pushCase(results, prefix, "operator-refund-and-signed-callback", "pending"); continue; }
    try {
      const expectedAmounts = entry.refund.expectedAmountsMinor;
      if (expectedAmounts) {
        assert(JSON.stringify([...supplied.refunds].map((item) => item.amountMinor).sort()) === JSON.stringify([...expectedAmounts].sort()),
          "Operator refund evidence does not match the configured approved refund amounts.");
      }
      let cumulative = 0n;
      const chargeAmount = BigInt(chargeFingerprint.split(":")[2]);
      const refundEventIds = new Set<string>();
      const refundIds = new Set<string>();
      let finalPaymentStatus = "";
      for (const refund of supplied.refunds) {
        assert(/^[1-9]\d*$/.test(refund.amountMinor), "Refund evidence amountMinor must be a positive integer string.");
        const body = verifySignedCallback(refund.callback, secret!);
        cumulative += BigInt(refund.amountMinor);
        assert(cumulative <= chargeAmount, "Refund evidence cumulatively exceeds immutable original charge.");
        assert(refund.callback.linkedResourceIds.orderId === orderId && refund.callback.linkedResourceIds.paymentAttemptId === persisted.paymentAttemptId,
          "Refund callback evidence links a different order or payment attempt.");
        assert(typeof refund.callback.linkedResourceIds.refundId === "string", "Refund callback evidence must declare its exact refund ID.");
        const refundId = refund.callback.linkedResourceIds.refundId;
        assert(!refundEventIds.has(refund.callback.eventId) && !refundIds.has(refundId),
          "Refund callback evidence contains a duplicate event ID or refund ID.");
        refundEventIds.add(refund.callback.eventId); refundIds.add(refundId);
        const refundData = requireRefundEvidence(body, {
          orderId: orderId!, attemptId: persisted.paymentAttemptId!, refundId: refund.callback.linkedResourceIds.refundId,
          amountMinor: refund.amountMinor, currency: entry.chargeCurrency, fingerprint: chargeFingerprint,
        });
        finalPaymentStatus = getString(refundData.paymentStatus, "Refund callback paymentStatus");
        pushCase(results, prefix, "operator-refund-and-signed-callback", "passed", { amountMinor: refund.amountMinor, callback: body });
      }
      assert(cumulative === chargeAmount ? finalPaymentStatus === "refunded" : finalPaymentStatus === "partially_refunded",
        "Refund callback terminal state does not match the cumulative returned amount.");
      if (entry.refund.requireReplayAndOverRefundRejection) {
        const controls = supplied.refundControls;
        if (!controls) {
          pushCase(results, prefix, "refund-replay-and-over-refund-rejection", "pending");
        } else {
          assert(refundIds.has(controls.exactReplay.refundId) && idKey.test(controls.exactReplay.idempotencyKey)
            && controls.exactReplay.outcome === "same_refund_returned",
          "Refund replay evidence must identify one captured refund ID, a valid key, and the original returned refund.");
          assert(/^[1-9]\d*$/.test(controls.overRefundRejection.attemptedAmountMinor)
            && BigInt(controls.overRefundRejection.attemptedAmountMinor) > chargeAmount - cumulative
            && (controls.overRefundRejection.httpStatus === 409 || controls.overRefundRejection.httpStatus === 422)
            && controls.overRefundRejection.errorCode.trim(),
          "Over-refund rejection evidence must attempt more than remaining charge and report explicit 409/422 failure.");
          pushCase(results, prefix, "refund-replay-and-over-refund-rejection", "passed", controls);
        }
      }
    } catch (error) { pushCase(results, prefix, "operator-refund-and-signed-callback", "failed", error instanceof Error ? error.message : String(error)); }
  }
  const all = results.cases as Json[];
  results.status = all.some((item) => item.status === "failed") ? "failed" : all.some((item) => item.status === "pending") ? "incomplete" : "passed";
  return results;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  const value = (flag: string) => {
    const index = args.indexOf(flag);
    return index >= 0 ? args[index + 1] : undefined;
  };
  const known = new Set(["--execute", "--config", "--output", "--state", "--evidence"]);
  assert(args.every((item) => known.has(item) || !item.startsWith("--"))
    && args.filter((item) => item === "--execute").length === 1
    && args.filter((item) => item === "--config").length === 1
    && args.filter((item) => item === "--output").length === 1
    && args.filter((item) => item === "--state").length === 1
    && args.filter((item) => item === "--evidence").length <= 1
    && args.includes("--execute") && value("--config") && value("--output") && value("--state")
    && !value("--config")!.startsWith("--") && !value("--output")!.startsWith("--") && !value("--state")!.startsWith("--")
    && (!value("--evidence") || !value("--evidence")!.startsWith("--")),
  "Usage: ... --execute --config <approved-config.json> --state <nonsecret-resume-state.json> --output <sanitized-results.json> [--evidence <operator-evidence.json>].");
  const config = validateAcceptanceConfig(JSON.parse(await readFile(value("--config")!, "utf8")));
  const evidencePath = value("--evidence");
  const evidence = evidencePath ? JSON.parse(await readFile(evidencePath, "utf8")) as OperatorEvidence : undefined;
  if (evidence) assert(evidence.packageVersion === "3.5" && Array.isArray(evidence.cases), "Operator evidence must be a v3.5 evidence file.");
  const results = await runAcceptance(config, evidence, value("--state")!);
  await writeFile(value("--output")!, `${JSON.stringify(results, null, 2)}\n`, { mode: 0o600 });
  console.log(`Acceptance status: ${results.status}. Sanitized results: ${path.basename(value("--output")!)}`);
  process.exitCode = results.status === "passed" ? 0 : results.status === "incomplete" ? 2 : 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((error) => { console.error(error instanceof Error ? error.message : String(error)); process.exitCode = 1; });
}