# SOSO ↔ JusticeSure Headless Commerce Integration Handoff

**Package:** SOSO JusticeSure Headless Commerce Handoff v3.0  
**Prepared:** 7 September 2026  
**Target storefront:** `https://soso-africa-site.vercel.app/`  
**API contract:** `justicesure-headless-commerce-openapi-v1.json`

## Start here

Give this entire ZIP to SOSO's Replit Agent and ask it to read this file and the
OpenAPI document before changing the storefront.

The OpenAPI document is the machine-readable source of truth for request and
response fields. This guide defines the required architecture, security,
recovery, and acceptance behavior.

The package contains no API keys, webhook secrets, payment credentials,
database credentials, or production access. Those must be provisioned and
transferred separately using Replit integrations/secrets, never chat or source
control.

## Copy/paste brief for SOSO's Replit Agent

> Integrate the existing SOSO Vercel storefront with JusticeSure Headless
> Commerce using this package. Preserve SOSO's current visual design and public
> URLs. Implement all JusticeSure calls server-side. Treat the included OpenAPI
> JSON as the request/response source of truth. Replace locally authoritative
> catalogue, price, stock, checkout, order, payment, and fulfilment state with
> JusticeSure data. Use immutable price quotes, durable idempotency keys,
> merchant-owned payment readiness discovery, hosted payment sessions, signed
> raw-body webhooks, and durable webhook leases/deduplication. Never expose a
> JusticeSure API key or webhook secret to browser JavaScript. Do not mark an
> order paid from a return URL or client assertion. Implement staging first and
> complete the acceptance matrix in this guide before production activation.

## 1. Authority boundary

JusticeSure is authoritative for:

- enabled store profile, products, variants, visibility, prices, and stock;
- supported currencies and payment-method readiness;
- immutable payable price quotes and delivery/carrier calculations;
- order creation, totals, status, payment state, and fulfilment state;
- merchant-owned payment-account selection and hosted payment initialization;
- provider webhook verification and authoritative payment transitions.

SOSO owns:

- the storefront presentation and customer journey;
- its server-side JusticeSure adapter;
- customer session/cart convenience state before quoting;
- its local projection of JusticeSure order state for fast UI rendering;
- signed JusticeSure webhook receipt, durable processing, and local side
  effects.

SOSO must not:

- calculate an authoritative payable total in the browser;
- trust stale locally cached price or stock at checkout;
- send provider credentials to JusticeSure through the commerce API;
- select or override a private merchant payment-account identifier;
- mark an order paid, fulfilled, cancelled, or refunded locally;
- expose private carrier, connector, gateway, or authority metadata;
- reuse a key issued for another business or JusticeSure entity.

Each JusticeSure commerce API key is bound to exactly one business/entity. It
must never be shared between sibling companies or storefronts.

## 2. Server-side configuration

Configure placeholders like these through the SOSO project's secret manager:

```text
JUSTICESURE_COMMERCE_API_BASE_URL=https://justicesure.ai/api/v1/commerce
JUSTICESURE_COMMERCE_API_KEY=<provisioned separately>
JUSTICESURE_COMMERCE_WEBHOOK_SECRET=<provisioned separately>
SOSO_PAYMENT_RETURN_URL=https://soso-africa-site.vercel.app/<payment-return-route>
SOSO_JUSTICESURE_WEBHOOK_URL=https://soso-africa-site.vercel.app/<webhook-route>
STOREFRONT_DATABASE_URL=<durable SOSO database>
```

Do not prefix secret variables with `NEXT_PUBLIC_`, `VITE_`, or any equivalent
browser-exposed convention.

Every Commerce API request must be made from SOSO's backend with:

```http
Authorization: Bearer jsk_...
Accept: application/json
Content-Type: application/json
```

Write requests that the OpenAPI contract marks idempotent also require:

```http
Idempotency-Key: <durable unique operation key>
```

## 3. Current endpoint map

Paths are relative to `/api/v1/commerce`.

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/store` | Enabled public store profile |
| `GET` | `/categories` | Categories represented by visible products |
| `GET` | `/locations` | Customer-selectable selling locations |
| `GET` | `/currencies` | ISO-4217 display/capability metadata |
| `GET` | `/payment-methods` | Merchant-owned payment readiness and routes |
| `GET` | `/fulfillment-corridors` | Approved international carrier corridors |
| `GET` | `/products` | Visible, sellable products and variants |
| `GET` | `/products/{productId}` | One visible product |
| `POST` | `/delivery-quotes` | Signed delivery quote for legacy/domestic flow |
| `POST` | `/price-quotes` | Immutable authoritative payable cart quote |
| `GET` | `/price-quotes/{quoteId}` | Retrieve a still-valid immutable quote |
| `POST` | `/orders` | Idempotent order creation |
| `GET` | `/orders/{orderId}` | Authoritative order/payment/fulfilment status |
| `POST` | `/orders/{orderId}/payment-sessions` | Approved hosted payment initialization |

`POST /providers/webhooks/{provider}/{merchantAccountId}` is the
JusticeSure-owned raw provider webhook ingress. SOSO must not call it or proxy
provider events to it. Payment providers call that JusticeSure route directly.
SOSO receives normalized JusticeSure commerce events at SOSO's registered
webhook URL.

Use the OpenAPI document for scopes, filters, request bodies, response
discriminators, reason codes, and error bodies.

## 4. Required storefront flow

### 4.1 Catalogue

Render catalogue/category/product pages from `GET /products` and
`GET /products/{productId}`. Respect only returned products and variants.

Catalogue responses may be cached for presentation, but checkout must always
obtain a new authoritative quote. A product displayed earlier can become
unavailable before checkout.

### 4.2 Discover capabilities

Before presenting checkout choices:

1. Read `/currencies` for display and capability metadata.
2. Read `/payment-methods` and offer only methods currently reported ready.
3. For international delivery, read `/fulfillment-corridors` and offer only
   approved, enabled corridors returned for the bound merchant.

Currency availability for display is not proof that a payment account can
charge that currency. Payment readiness is authoritative.

### 4.3 Create an immutable price quote

Send the current product/variant quantities and fulfilment facts to
`POST /price-quotes`.

For international delivery, send the complete structured address and package
facts required by the OpenAPI schema. JusticeSure freezes carrier rate,
validated address, customs/tax/duty facts, restricted-goods policy,
importer-of-record information, landed-cost disclosure, policy revision, and
policy hash into the quote.

JusticeSure persists a payable quote only after the exact merchant-owned
payment connector passes a side-effect-free readiness check. If it reports
`EXACT_PAYMENT_ACCOUNT_CONNECTOR_UNAVAILABLE`, show a recoverable checkout
message and do not create an order.

Persist the returned quote identifier and expiry. Never alter quoted money
locally. If JusticeSure reports `QUOTE_EXPIRED_REQUOTE_REQUIRED`, create a new
quote and ask the customer to review any changed amount.

### 4.4 Create the order

Create the order using the immutable quote contract required by the OpenAPI
document. Generate and durably persist an order idempotency key before the
first network attempt.

On timeout or ambiguous response, retry the exact request with the same key.
Do not create a second key merely because the first response was lost. Never
reuse the key for a changed cart, quote, customer, address, or order attempt.

Once a key is bound to an order, recover that same order. A changed payload
with the same key must be treated as a conflict, not as a new checkout.

### 4.5 Initialize hosted payment

Use `POST /orders/{orderId}/payment-sessions` with a separate durable
idempotency key. The provider must be one reported ready by
`GET /payment-methods` and compatible with the frozen quote/order.

The current contract can return provider-discriminated hosted checkout
responses, including Paystack, Flutterwave, Stripe, PayPal, and Hydrogen when
the merchant has an approved, ready account.

Persist the JusticeSure order ID, provider, payment reference, checkout URL,
request body, and payment-session idempotency key before redirecting.

An exact replay must recover the same usable session. If the browser closes or
the response is lost, retry the exact session request with the same key.

Payment-session creation means **pending**, not paid.

### 4.6 Payment return

The browser return route is only customer navigation. It must:

1. display a pending/processing state;
2. query SOSO's backend, which queries `GET /orders/{orderId}`;
3. render only JusticeSure's authoritative payment/order state;
4. offer safe retry/status refresh where appropriate.

Never mark an order paid from query parameters, a provider JavaScript callback,
the existence of a payment reference, or the customer's redirect.

## 5. JusticeSure webhook receiver

Register a public HTTPS SOSO backend route. It must receive the raw request
bytes before JSON parsing.

JusticeSure sends:

```text
X-JusticeSure-Timestamp
X-JusticeSure-Event-Id
X-JusticeSure-Signature
```

Verify:

```text
HMAC-SHA256(
  webhookSecret,
  timestamp + "." + eventId + "." + rawRequestBody
)
```

Compare signatures in constant time after handling the documented `sha256=`
prefix. Reject malformed headers, invalid signatures, and stale timestamps;
five minutes is the recommended replay tolerance.

Use `examples/headless-commerce-staging/webhook-receiver.ts` as the verification
reference.

### Durable processing requirements

Do not use an in-memory set as the event store.

Before side effects, atomically claim the event ID in a durable database with a
processing lease. The processor must distinguish:

- completed: return success without repeating side effects;
- actively processing: return non-2xx so JusticeSure retries;
- expired lease or failed attempt: reclaim and continue;
- new event: claim and process.

Every local side effect must itself be idempotent by event ID. Mark completion
only after all required effects commit. If work remains unfinished, return
non-2xx. A JusticeSure retry carries the same event ID.

Use `postgres-webhook-store.ts` as the durable lease reference, then adapt its
SQL to SOSO's existing database conventions.

Expected normalized event families include catalogue, inventory, order,
payment, cancellation, refund, and fulfilment updates. Handle only event types
documented by the current contract/runtime and safely acknowledge supported
no-op events after recording them.

## 6. Error and retry rules

- `400`: fix the malformed request; do not retry unchanged.
- `401`: key missing, invalid, expired, or revoked; fail closed.
- `403`: key lacks scope or is outside its exact entity boundary; fail closed.
- `404`: do not substitute a locally invented resource.
- `409`: idempotency/payload or state conflict; recover the original operation
  or require a deliberate new customer attempt.
- `422`: catalogue, price, delivery, payment-readiness, quote, or stock
  condition is not currently fulfillable; display a safe user action.
- `429`: obey `Retry-After` and `RateLimit-*`; back off with jitter.
- `5xx` or timeout: retry safe reads; retry writes only with the exact persisted
  idempotency key and unchanged body.

Set bounded connection and response timeouts. Persist operation claims before
calling JusticeSure so a function restart or Vercel retry cannot create a
duplicate logical operation.

## 7. Vercel/storefront implementation notes

- JusticeSure calls belong in server routes/actions only.
- Webhook signature verification must use raw bytes, not re-serialized JSON.
- Use a durable database; Vercel function memory and filesystem are not durable.
- Keep the existing SOSO design and URLs unless a route is needed for payment
  return or webhook receipt.
- Do not cache authenticated responses in a public CDN.
- Store only the minimum customer/order projection SOSO needs; JusticeSure
  remains authoritative.
- Do not expose gateway account IDs, provider secrets, carrier credentials, or
  JusticeSure private authority metadata in browser responses or logs.
- Scrub authorization headers, signatures, secrets, and sensitive customer
  fields from logs.

## 8. Staging acceptance matrix

SOSO's Agent should provide evidence for all of these before production:

### Boundary and catalogue

- A missing, malformed, revoked, or wrong-entity key fails closed.
- API keys and webhook secrets are absent from browser bundles and network
  requests.
- Product/category pages render JusticeSure data.
- Hidden, archived, raw-material, unavailable, or foreign-entity items do not
  appear.
- A stale displayed price/stock is rejected or refreshed during quoting.

### Quotes, delivery, and payments

- Currency and payment choices come from discovery endpoints.
- Only ready merchant-owned payment methods are offered.
- Domestic pickup/delivery quoting works as configured.
- International delivery is offered only for returned approved corridors.
- Expired quotes force requoting and customer review.
- Missing exact payment connector fails before order/stock mutation.
- The same order request/key yields one order after timeout/retry.
- A changed order payload with the same key is rejected.
- The same payment-session request/key recovers one provider session.
- Session creation and return navigation leave payment pending until verified.

### Webhooks and recovery

- Invalid signature, stale timestamp, and malformed headers are rejected.
- Duplicate completed event IDs do not repeat side effects.
- Concurrent delivery cannot run the same event side effects twice.
- A non-2xx/failed attempt is visible and can be retried.
- An expired processing lease can be reclaimed after a simulated crash.
- Payment, refund, cancellation, and fulfilment UI follows authoritative
  JusticeSure status.

### Operations

- Rate limiting honors `Retry-After`.
- Secrets and sensitive headers are redacted from logs.
- Staging and production use separate keys/secrets where provisioned.
- Production HTTPS webhook and payment-return URLs are correct.
- Exposed test credentials are rotated before launch.

## 9. Owner actions performed separately

The JusticeSure merchant/owner must separately:

1. enable Headless Commerce for the exact SOSO business/entity;
2. confirm public catalogue, locations, currencies, and fulfilment settings;
3. activate and qualify merchant-owned payment accounts;
4. approve any international carrier corridors;
5. create a least-privilege SOSO API key;
6. register SOSO's HTTPS webhook URL and selected event subscriptions;
7. transfer the API key and webhook secret through secure secret management;
8. retain the ability to revoke/rotate credentials and inspect delivery
   history.

No payment-provider key, carrier credential, or JusticeSure production
credential should be handed to SOSO's Agent in this ZIP.

## 10. Package files

- `START_HERE.md` — this SOSO-specific implementation handoff.
- `justicesure-headless-commerce-openapi-v1.json` — current machine-readable
  contract.
- `examples/headless-commerce-staging/` — typed server client, webhook verifier,
  durable PostgreSQL lease store, sample server, and implementation notes.
- `SHA256SUMS.txt` — integrity hashes for every packaged implementation file.
- `PACKAGE_MANIFEST.txt` — sorted archive file list and package metadata.

If prose and the OpenAPI document disagree on a field or response shape, stop
and follow the OpenAPI document. If a live staging response disagrees with the
OpenAPI contract, do not invent a fallback; capture the sanitized response and
request a JusticeSure contract correction.