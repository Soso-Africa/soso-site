/**
 * JusticeSure Headless Commerce client for a trusted storefront backend.
 *
 * This module must only be imported by server-side code. It deliberately owns
 * the Authorization header so browser input can never replace or read the
 * Commerce API key.
 */

export type CommerceFetch = (
  input: string | URL | Request,
  init?: RequestInit,
) => Promise<Response>;

export type CartLine = {
  productId: string;
  variantId?: string;
  quantity: number;
};

export type CheckoutRequest = {
  customer: {
    name: string;
    email: string;
    phone?: string;
  };
  items: CartLine[];
  fulfillment: {
    type: "pickup" | "delivery";
    locationId?: string;
    address?: string;
    deliveryQuoteToken?: string;
  };
  paymentMethod: "paystack" | "flutterwave";
  notes?: string;
};

export type CommerceClientOptions = {
  baseUrl: string;
  apiKey: string;
  fetchImpl?: CommerceFetch;
  maxRateLimitRetries?: number;
  sleep?: (milliseconds: number) => Promise<void>;
  /**
   * Development-only escape hatch for a loopback JusticeSure server.
   * Non-loopback HTTP URLs remain forbidden.
   */
  allowInsecureLoopback?: boolean;
};

type RequestOptions = {
  method?: "GET" | "POST";
  body?: unknown;
  idempotencyKey?: string;
  idempotencyRequired?: boolean;
};

const IDEMPOTENCY_KEY = /^[A-Za-z0-9_.:-]{8,64}$/;

export class CommerceApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId?: string;
  readonly retryAfterSeconds?: number;

  constructor(input: {
    status: number;
    code: string;
    message: string;
    requestId?: string;
    retryAfterSeconds?: number;
  }) {
    super(input.message);
    this.name = "CommerceApiError";
    this.status = input.status;
    this.code = input.code;
    this.requestId = input.requestId;
    this.retryAfterSeconds = input.retryAfterSeconds;
  }
}

function normalizeBaseUrl(raw: string, allowInsecureLoopback: boolean): string {
  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    throw new Error("JUSTICESURE_COMMERCE_BASE_URL must be a valid absolute URL.");
  }

  const loopback = parsed.hostname === "127.0.0.1"
    || parsed.hostname === "::1"
    || parsed.hostname === "localhost";
  if (parsed.protocol !== "https:" && !(allowInsecureLoopback && loopback && parsed.protocol === "http:")) {
    throw new Error("JusticeSure Commerce API requests must use HTTPS.");
  }
  if (parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new Error("The Commerce API base URL must not contain credentials, a query, or a fragment.");
  }

  return parsed.toString().replace(/\/+$/, "");
}

function assertServerApiKey(apiKey: string): void {
  if (!apiKey.startsWith("jsk_") || apiKey.length < 12) {
    throw new Error("JUSTICESURE_COMMERCE_API_KEY is missing or malformed.");
  }
}

function assertPath(path: string): void {
  if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) {
    throw new Error("Commerce API paths must be relative paths beginning with one slash.");
  }
}

function retryAfterSeconds(value: string | null, nowMs = Date.now()): number {
  if (!value) return 1;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(1, Math.min(30, seconds));
  const dateMs = Date.parse(value);
  if (!Number.isFinite(dateMs)) return 1;
  return Math.max(1, Math.min(30, Math.ceil((dateMs - nowMs) / 1_000)));
}

async function responseBody(response: Response): Promise<any> {
  const text = await response.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    return { error: { code: "INVALID_RESPONSE", message: "JusticeSure returned a non-JSON response." } };
  }
}

export function createCommerceClient(options: CommerceClientOptions) {
  assertServerApiKey(options.apiKey);
  const baseUrl = normalizeBaseUrl(options.baseUrl, options.allowInsecureLoopback === true);
  const fetchImpl = options.fetchImpl ?? fetch;
  const maxRateLimitRetries = Math.max(0, Math.min(3, options.maxRateLimitRetries ?? 1));
  const sleep = options.sleep ?? ((milliseconds: number) =>
    new Promise<void>((resolve) => setTimeout(resolve, milliseconds)));

  async function request<T>(path: string, input: RequestOptions = {}): Promise<T> {
    assertPath(path);
    const method = input.method ?? "GET";
    if (input.idempotencyKey && !IDEMPOTENCY_KEY.test(input.idempotencyKey)) {
      throw new Error("Idempotency keys must be 8–64 characters using letters, numbers, _, ., :, or -.");
    }
    if (input.idempotencyRequired && !input.idempotencyKey) {
      throw new Error("This Commerce API operation requires a stable idempotency key.");
    }

    for (let attempt = 0; ; attempt += 1) {
      const response = await fetchImpl(`${baseUrl}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${options.apiKey}`,
          Accept: "application/json",
          ...(input.body === undefined ? {} : { "Content-Type": "application/json" }),
          ...(input.idempotencyKey ? { "Idempotency-Key": input.idempotencyKey } : {}),
        },
        body: input.body === undefined ? undefined : JSON.stringify(input.body),
      });

      if (response.status === 429 && attempt < maxRateLimitRetries) {
        const waitSeconds = retryAfterSeconds(response.headers.get("Retry-After"));
        // Consume the response before retrying so Undici/browser fetch can
        // release or reuse the underlying connection under sustained limits.
        await response.arrayBuffer().catch(() => undefined);
        await sleep(waitSeconds * 1_000);
        continue;
      }

      const body = await responseBody(response);
      if (!response.ok) {
        const nestedError = body?.error && typeof body.error === "object" ? body.error : null;
        throw new CommerceApiError({
          status: response.status,
          code: nestedError?.code
            ?? body?.code
            ?? (response.status === 401 ? "UNAUTHORIZED" : "COMMERCE_API_ERROR"),
          message: nestedError?.message
            ?? body?.message
            ?? (typeof body?.error === "string" ? body.error : `JusticeSure Commerce API returned HTTP ${response.status}.`),
          requestId: body?.requestId,
          retryAfterSeconds: response.status === 429
            ? retryAfterSeconds(response.headers.get("Retry-After"))
            : undefined,
        });
      }
      return body as T;
    }
  }

  return {
    getStore: () => request<{ data: unknown }>("/store"),
    getLocations: () => request<{ data: unknown[] }>("/locations"),
    getCategories: () => request<{ data: unknown[] }>("/categories"),
    getProducts: (query = "") =>
      request<{ data: unknown[]; meta: unknown }>(`/products${query ? `?${query}` : ""}`),
    getProduct: (productId: string, query = "") =>
      request<{ data: unknown }>(`/products/${encodeURIComponent(productId)}${query ? `?${query}` : ""}`),
    getDeliveryQuote: (body: { items: CartLine[]; address: string; locationId?: string }) =>
      request<{ data: { quoteToken: string; feeKobo: number; cartSubtotalKobo: number } }>(
        "/delivery-quotes",
        { method: "POST", body },
      ),
    createOrder: (body: CheckoutRequest, idempotencyKey: string) =>
      request<{ data: { id: string; payment: { status: string }; amounts: { totalKobo: number } } }>(
        "/orders",
        { method: "POST", body, idempotencyKey, idempotencyRequired: true },
      ),
    createPaymentSession: (
      orderId: string,
      body: { provider: "paystack" | "flutterwave"; email?: string; redirectUrl?: string },
      idempotencyKey: string,
    ) => request<{ data: { checkoutUrl: string | null; reference: string; status?: string } }>(
      `/orders/${encodeURIComponent(orderId)}/payment-sessions`,
      { method: "POST", body, idempotencyKey, idempotencyRequired: true },
    ),
    getOrder: (orderId: string) =>
      request<{ data: { id: string; payment: { status: string }; fulfillment: { status: string } } }>(
        `/orders/${encodeURIComponent(orderId)}`,
      ),
  };
}

export function createCommerceClientFromEnv(
  env: Record<string, string | undefined> = process.env,
  overrides: Pick<CommerceClientOptions, "fetchImpl" | "sleep" | "maxRateLimitRetries" | "allowInsecureLoopback"> = {},
) {
  return createCommerceClient({
    baseUrl: env.JUSTICESURE_COMMERCE_BASE_URL ?? "",
    apiKey: env.JUSTICESURE_COMMERCE_API_KEY ?? "",
    ...overrides,
  });
}