/**
 * Runnable staging backend:
 *   npx tsx examples/headless-commerce-staging/example-server.ts
 *
 * The JusticeSure Commerce key is read only from this server process. Browser
 * requests authenticate with a separate staging access token. Replace that
 * staging gate with your real customer/session authorization before production.
 */
import crypto from "node:crypto";
import express from "express";
import { Pool } from "pg";
import { z } from "zod";
import { createCommerceClientFromEnv } from "./commerce-client";
import { PostgresCommerceWebhookStore } from "./postgres-webhook-store";
import { processCommerceWebhook } from "./webhook-receiver";

const envSchema = z.object({
  JUSTICESURE_COMMERCE_BASE_URL: z.string().url(),
  JUSTICESURE_COMMERCE_API_KEY: z.string().startsWith("jsk_").min(12),
  JUSTICESURE_COMMERCE_WEBHOOK_SECRET: z.string().min(16),
  STOREFRONT_DATABASE_URL: z.string().min(1),
  STOREFRONT_STAGING_ACCESS_TOKEN: z.string().min(16),
  PORT: z.string().regex(/^\d+$/).optional(),
});
const env = envSchema.parse(process.env);

const commerce = createCommerceClientFromEnv(env);
const pool = new Pool({ connectionString: env.STOREFRONT_DATABASE_URL });
const webhookStore = new PostgresCommerceWebhookStore(pool);
await webhookStore.ensureSchema();

const app = express();

function safeEqual(left: string, right: string): boolean {
  const leftBytes = Buffer.from(left);
  const rightBytes = Buffer.from(right);
  return leftBytes.length === rightBytes.length && crypto.timingSafeEqual(leftBytes, rightBytes);
}

app.get("/health", (_req, res) => {
  res.json({ ok: true, commerceKeyLoaded: true });
});

app.post(
  "/webhooks/justicesure-commerce",
  express.raw({ type: "application/json", limit: "256kb" }),
  async (req, res) => {
    try {
      const result = await processCommerceWebhook({
        secret: env.JUSTICESURE_COMMERCE_WEBHOOK_SECRET,
        headers: req.headers,
        rawBody: Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body ?? ""),
        store: webhookStore,
        handle: async (event) => {
          // Replace this with idempotent catalogue/order synchronization.
          // Keep the event ID as the idempotency key for every local side effect.
          console.info("[commerce-staging] verified event", event.id, event.event);
        },
      });
      res.status(result.status).json(result);
    } catch (error) {
      console.error("[commerce-staging] webhook receiver failed unexpectedly", error);
      res.status(503).json({
        status: 503,
        code: "RECEIVER_UNAVAILABLE",
        message: "The webhook receiver is temporarily unavailable. JusticeSure may retry it.",
      });
    }
  },
);

app.use(express.json({ limit: "256kb" }));
app.use("/staging", (req, res, next) => {
  const supplied = String(req.headers["x-staging-access-token"] ?? "");
  if (!safeEqual(supplied, env.STOREFRONT_STAGING_ACCESS_TOKEN)) {
    return res.status(401).json({ error: "Invalid staging access token." });
  }
  next();
});

app.get("/staging/store", async (_req, res, next) => {
  try { res.json(await commerce.getStore()); } catch (error) { next(error); }
});
app.get("/staging/locations", async (_req, res, next) => {
  try { res.json(await commerce.getLocations()); } catch (error) { next(error); }
});
app.get("/staging/categories", async (_req, res, next) => {
  try { res.json(await commerce.getCategories()); } catch (error) { next(error); }
});
app.get("/staging/products", async (req, res, next) => {
  try {
    const allowed = new URLSearchParams();
    for (const key of ["limit", "offset", "search", "category", "locationId"]) {
      if (typeof req.query[key] === "string") allowed.set(key, req.query[key] as string);
    }
    res.json(await commerce.getProducts(allowed.toString()));
  } catch (error) { next(error); }
});

const line = z.object({
  productId: z.string().uuid(),
  variantId: z.string().uuid().optional(),
  quantity: z.number().int().positive().max(10_000),
}).strict();
const lines = z.array(line).min(1).max(100);

app.post("/staging/delivery-quotes", async (req, res, next) => {
  try {
    const body = z.object({
      items: lines,
      address: z.string().trim().min(5).max(2_000),
      locationId: z.string().uuid().optional(),
    }).strict().parse(req.body);
    res.json(await commerce.getDeliveryQuote(body));
  } catch (error) { next(error); }
});

app.post("/staging/orders", async (req, res, next) => {
  try {
    const body = z.object({
      idempotencyKey: z.string().regex(/^[A-Za-z0-9_.:-]{8,64}$/),
      customer: z.object({
        name: z.string().trim().min(1).max(255),
        email: z.string().trim().email().max(255),
        phone: z.string().trim().min(5).max(50).optional(),
      }).strict(),
      items: lines,
      fulfillment: z.object({
        type: z.enum(["pickup", "delivery"]),
        locationId: z.string().uuid().optional(),
        address: z.string().trim().min(5).max(2_000).optional(),
        deliveryQuoteToken: z.string().min(20).max(4_000).optional(),
      }).strict(),
      paymentMethod: z.enum(["paystack", "flutterwave"]),
      notes: z.string().trim().max(2_000).optional(),
    }).strict().parse(req.body);
    const { idempotencyKey, ...order } = body;
    res.json(await commerce.createOrder(order, idempotencyKey));
  } catch (error) { next(error); }
});

app.post("/staging/orders/:orderId/payment-sessions", async (req, res, next) => {
  try {
    const orderId = z.string().uuid().parse(req.params.orderId);
    const body = z.object({
      idempotencyKey: z.string().regex(/^[A-Za-z0-9_.:-]{8,64}$/),
      provider: z.enum(["paystack", "flutterwave"]),
      email: z.string().email().optional(),
      redirectUrl: z.string().url().optional(),
    }).strict().parse(req.body);
    const { idempotencyKey, ...session } = body;
    res.json(await commerce.createPaymentSession(orderId, session, idempotencyKey));
  } catch (error) { next(error); }
});

app.get("/staging/orders/:orderId", async (req, res, next) => {
  try {
    res.json(await commerce.getOrder(z.string().uuid().parse(req.params.orderId)));
  } catch (error) { next(error); }
});

app.use((error: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error("[commerce-staging]", error?.code ?? error?.name ?? "ERROR", error?.message ?? error);
  const status = error instanceof z.ZodError ? 400 : Number(error?.status) || 500;
  res.status(status).json({
    error: {
      code: error?.code ?? "STAGING_BACKEND_ERROR",
      message: error?.message ?? "Request failed.",
    },
  });
});

const port = Number(env.PORT ?? 4010);
app.listen(port, "0.0.0.0", () => {
  console.info(`[commerce-staging] listening on port ${port}`);
});