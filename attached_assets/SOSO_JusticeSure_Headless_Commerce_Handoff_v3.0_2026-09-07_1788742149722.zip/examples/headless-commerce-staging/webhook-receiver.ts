import crypto from "node:crypto";

export const COMMERCE_WEBHOOK_EVENTS = [
  "commerce.product.updated",
  "commerce.inventory.updated",
  "commerce.order.created",
  "commerce.order.updated",
  "commerce.payment.updated",
  "commerce.order.cancelled",
  "commerce.order.refunded",
  "commerce.fulfilment.updated",
] as const;

export type CommerceWebhookEvent = typeof COMMERCE_WEBHOOK_EVENTS[number];

export type CommerceWebhookEnvelope = {
  id: string;
  event: CommerceWebhookEvent;
  apiVersion: string;
  createdAt: string;
  data: Record<string, unknown>;
};

export type WebhookHeaders = Headers | Record<string, string | string[] | undefined>;

export type VerifiedWebhook = {
  eventId: string;
  eventType: CommerceWebhookEvent;
  timestamp: number;
  rawBody: Buffer;
  payloadHash: string;
  envelope: CommerceWebhookEnvelope;
};

export type CommerceWebhookStore = {
  /**
   * Atomically persist the event ID before processing.
   * Return "duplicate" when an already-processed/in-flight event is delivered.
   * A failed event must become claimable again for JusticeSure's retry.
   */
  claim(event: VerifiedWebhook): Promise<"claimed" | "processed" | "in_progress">;
  markProcessed(eventId: string): Promise<void>;
  markFailed(eventId: string, error: unknown): Promise<void>;
};

export type WebhookProcessingResult =
  | { status: 200; duplicate: boolean; eventId: string }
  | { status: 400 | 401; code: string; message: string }
  | {
      status: 503;
      code: "PROCESSING_FAILED" | "EVENT_IN_PROGRESS" | "STORE_UNAVAILABLE";
      message: string;
      eventId: string;
    };

const EVENT_ID = /^evt_[A-Za-z0-9_-]{8,100}$/;
const SIGNATURE = /^sha256=([a-f0-9]{64})$/;
const EVENT_SET = new Set<string>(COMMERCE_WEBHOOK_EVENTS);

function header(headers: WebhookHeaders, name: string): string {
  if (headers instanceof Headers) return headers.get(name) ?? "";
  const wanted = name.toLowerCase();
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() !== wanted) continue;
    return Array.isArray(value) ? value[0] ?? "" : value ?? "";
  }
  return "";
}

function rawBuffer(rawBody: Buffer | Uint8Array | string): Buffer {
  if (Buffer.isBuffer(rawBody)) return rawBody;
  return Buffer.from(rawBody);
}

export function verifyCommerceWebhook(input: {
  secret: string;
  headers: WebhookHeaders;
  rawBody: Buffer | Uint8Array | string;
  nowMs?: number;
  toleranceSeconds?: number;
}): VerifiedWebhook {
  if (!input.secret) throw Object.assign(new Error("Webhook signing secret is not configured."), { code: "SECRET_MISSING" });

  const signature = header(input.headers, "X-JusticeSure-Signature");
  const timestampText = header(input.headers, "X-JusticeSure-Timestamp");
  const eventId = header(input.headers, "X-JusticeSure-Event-Id");
  const eventType = header(input.headers, "X-JusticeSure-Event");
  const signatureMatch = signature.match(SIGNATURE);
  const timestamp = Number(timestampText);

  if (!signatureMatch || !Number.isSafeInteger(timestamp) || !EVENT_ID.test(eventId)) {
    throw Object.assign(new Error("Required webhook authentication headers are missing or malformed."), {
      code: "INVALID_HEADERS",
    });
  }

  const toleranceSeconds = Math.max(1, Math.min(3_600, input.toleranceSeconds ?? 300));
  const nowSeconds = Math.floor((input.nowMs ?? Date.now()) / 1_000);
  if (Math.abs(nowSeconds - timestamp) > toleranceSeconds) {
    throw Object.assign(new Error("Webhook timestamp is outside the accepted replay window."), {
      code: "STALE_TIMESTAMP",
    });
  }

  const body = rawBuffer(input.rawBody);
  const signedPrefix = Buffer.from(`${timestampText}.${eventId}.`, "utf8");
  const expected = crypto
    .createHmac("sha256", input.secret)
    .update(Buffer.concat([signedPrefix, body]))
    .digest();
  const supplied = Buffer.from(signatureMatch[1], "hex");
  if (supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected)) {
    throw Object.assign(new Error("Webhook signature is invalid."), { code: "INVALID_SIGNATURE" });
  }

  let envelope: CommerceWebhookEnvelope;
  try {
    envelope = JSON.parse(body.toString("utf8"));
  } catch {
    throw Object.assign(new Error("Webhook body is not valid JSON."), { code: "INVALID_BODY" });
  }

  if (
    envelope?.id !== eventId
    || envelope?.event !== eventType
    || !EVENT_SET.has(envelope?.event)
    || typeof envelope?.apiVersion !== "string"
    || typeof envelope?.createdAt !== "string"
    || !envelope?.data
    || typeof envelope.data !== "object"
    || Array.isArray(envelope.data)
  ) {
    throw Object.assign(new Error("Webhook envelope does not match its authenticated headers."), {
      code: "ENVELOPE_MISMATCH",
    });
  }

  return {
    eventId,
    eventType: envelope.event,
    timestamp,
    rawBody: body,
    payloadHash: crypto.createHash("sha256").update(body).digest("hex"),
    envelope,
  };
}

export async function processCommerceWebhook(input: {
  secret: string;
  headers: WebhookHeaders;
  rawBody: Buffer | Uint8Array | string;
  store: CommerceWebhookStore;
  handle: (event: CommerceWebhookEnvelope) => Promise<void>;
  nowMs?: number;
  toleranceSeconds?: number;
}): Promise<WebhookProcessingResult> {
  let verified: VerifiedWebhook;
  try {
    verified = verifyCommerceWebhook(input);
  } catch (error: any) {
    const code = String(error?.code ?? "INVALID_WEBHOOK");
    return {
      status: code === "INVALID_BODY" || code === "ENVELOPE_MISMATCH" ? 400 : 401,
      code,
      message: error?.message ?? "Webhook verification failed.",
    };
  }

  let claim: "claimed" | "processed" | "in_progress";
  try {
    claim = await input.store.claim(verified);
  } catch {
    return {
      status: 503,
      code: "STORE_UNAVAILABLE",
      message: "The event could not be durably claimed. JusticeSure may retry it.",
      eventId: verified.eventId,
    };
  }
  if (claim === "processed") {
    return { status: 200, duplicate: true, eventId: verified.eventId };
  }
  if (claim === "in_progress") {
    // Do not acknowledge an unfinished event. A prior receiver process may
    // have crashed after claiming it; the sender must keep retrying until the
    // lease can be reclaimed or the first processor marks it complete.
    return {
      status: 503,
      code: "EVENT_IN_PROGRESS",
      message: "This event is still being processed. JusticeSure may retry it.",
      eventId: verified.eventId,
    };
  }

  try {
    await input.handle(verified.envelope);
  } catch (error) {
    await input.store.markFailed(verified.eventId, error).catch(() => undefined);
    return {
      status: 503,
      code: "PROCESSING_FAILED",
      message: "The event was verified but could not be processed. JusticeSure may retry it.",
      eventId: verified.eventId,
    };
  }

  try {
    await input.store.markProcessed(verified.eventId);
    return { status: 200, duplicate: false, eventId: verified.eventId };
  } catch (error) {
    // Make the event immediately reclaimable where possible. If the store is
    // unavailable, its processing lease will eventually expire instead.
    await input.store.markFailed(verified.eventId, error).catch(() => undefined);
    return {
      status: 503,
      code: "STORE_UNAVAILABLE",
      message: "The event completed but its durable receipt could not be recorded. JusticeSure may retry it.",
      eventId: verified.eventId,
    };
  }
}