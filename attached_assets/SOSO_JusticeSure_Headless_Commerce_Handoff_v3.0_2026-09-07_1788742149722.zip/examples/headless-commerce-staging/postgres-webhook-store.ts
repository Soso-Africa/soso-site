import type { Pool } from "pg";
import type { CommerceWebhookStore, VerifiedWebhook } from "./webhook-receiver";

/**
 * Durable event-id store for the staging receiver.
 *
 * Event handlers must still make their own side effects idempotent by event ID,
 * ideally in the same database transaction. That closes the small crash window
 * between a business side effect and markProcessed().
 */
export class PostgresCommerceWebhookStore implements CommerceWebhookStore {
  constructor(
    private readonly pool: Pool,
    private readonly processingLeaseSeconds = 300,
  ) {
    if (!Number.isSafeInteger(processingLeaseSeconds) || processingLeaseSeconds < 30 || processingLeaseSeconds > 3_600) {
      throw new Error("Webhook processing lease must be an integer from 30 to 3600 seconds.");
    }
  }

  async ensureSchema(): Promise<void> {
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS justicesure_commerce_webhook_events (
        event_id text PRIMARY KEY,
        event_type text NOT NULL,
        payload_sha256 text NOT NULL,
        status text NOT NULL CHECK (status IN ('processing', 'processed', 'failed')),
        attempts integer NOT NULL DEFAULT 1,
        last_error text,
        received_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        processed_at timestamptz
      )
    `);
  }

  async claim(event: VerifiedWebhook): Promise<"claimed" | "processed" | "in_progress"> {
    const inserted = await this.pool.query<{ event_id: string }>(`
      INSERT INTO justicesure_commerce_webhook_events (
        event_id, event_type, payload_sha256, status
      ) VALUES ($1, $2, $3, 'processing')
      ON CONFLICT (event_id) DO NOTHING
      RETURNING event_id
    `, [event.eventId, event.eventType, event.payloadHash]);
    if (inserted.rowCount === 1) return "claimed";

    const existing = await this.pool.query<{
      payload_sha256: string;
      status: "processing" | "processed" | "failed";
    }>(`
      SELECT payload_sha256, status
      FROM justicesure_commerce_webhook_events
      WHERE event_id = $1
    `, [event.eventId]);
    const row = existing.rows[0];
    if (!row || row.payload_sha256 !== event.payloadHash) {
      throw new Error("A webhook event ID was reused with a different payload.");
    }
    if (row.status === "processed") return "processed";

    const reclaimed = await this.pool.query<{ event_id: string }>(`
      UPDATE justicesure_commerce_webhook_events
      SET status = 'processing',
          attempts = attempts + 1,
          last_error = NULL,
          updated_at = now()
      WHERE event_id = $1
        AND payload_sha256 = $2
        AND (
          status = 'failed'
          OR (
            status = 'processing'
            AND updated_at < now() - ($3::integer * interval '1 second')
          )
        )
      RETURNING event_id
    `, [event.eventId, event.payloadHash, this.processingLeaseSeconds]);
    return reclaimed.rowCount === 1 ? "claimed" : "in_progress";
  }

  async markProcessed(eventId: string): Promise<void> {
    await this.pool.query(`
      UPDATE justicesure_commerce_webhook_events
      SET status = 'processed',
          processed_at = now(),
          updated_at = now(),
          last_error = NULL
      WHERE event_id = $1
    `, [eventId]);
  }

  async markFailed(eventId: string, error: unknown): Promise<void> {
    const message = error instanceof Error ? error.message : String(error);
    await this.pool.query(`
      UPDATE justicesure_commerce_webhook_events
      SET status = 'failed',
          last_error = left($2, 1000),
          updated_at = now()
      WHERE event_id = $1
    `, [eventId, message]);
  }
}