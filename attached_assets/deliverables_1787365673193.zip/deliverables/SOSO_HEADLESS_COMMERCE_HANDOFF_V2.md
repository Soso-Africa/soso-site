# SOSO ↔ JusticeSure Headless Commerce Integration Handoff

**Handoff version:** 2.0  
**JusticeSure Commerce API:** v1  
**Webhook envelope API version:** `2025-01-01`  
**Updated:** 22 August 2026

This document is the implementation and launch handoff for the SOSO storefront.
It supersedes `justicesure-headless-commerce-integration-brief.html`.

Share these two files with the SOSO developer:

1. `SOSO_HEADLESS_COMMERCE_HANDOFF_V2.md` — this document.
2. `justicesure-headless-commerce-openapi-v1.json` — the machine-readable API contract.

Do not put a real API key, webhook secret, payment-provider key, database URL, or
customer credential in either file.

---

## 1. Architecture: JusticeSure owns commerce and payment authority

SOSO is a custom headless storefront. It does **not** integrate directly with
Paystack or Flutterwave and must never receive those provider credentials.

```text
Shopper browser
    |
    | SOSO customer session
    v
SOSO trusted backend
    |
    | Authorization: Bearer jsk_...
    v
JusticeSure Headless Commerce API
    |
    | JusticeSure-controlled merchant/provider configuration
    v
Paystack or Flutterwave hosted checkout
    |
    | signed provider callback
    v
JusticeSure updates the authoritative order/payment
    |
    | signed commerce webhook
    v
SOSO backend updates its local customer-facing view
```

JusticeSure is authoritative for:

- catalogue visibility, variants and customer prices;
- stock and checkout availability;
- pickup/delivery policy and delivery fees;
- order totals;
- payment reference, amount, merchant account and platform fee;
- whether payment is verified;
- cancellation, refund and fulfilment state.

SOSO is responsible for:

- shopper registration/session security;
- proving that a shopper may view a requested JusticeSure `orderId`;
- keeping the `jsk_...` key and webhook secret server-only;
- durable webhook deduplication and local side effects;
- customer-facing payment return, pending, failure and order-status UX.

---

## 2. Authoritative URLs

| Item | URL |
| --- | --- |
| Production origin | `https://justicesure.ai` |
| Commerce API base URL | `https://justicesure.ai/api/v1/commerce` |
| OpenAPI 3.1 contract | `https://justicesure.ai/api/openapi/commerce-v1.json` |
| Interactive developer page | `https://justicesure.ai/developer-api` |

Do not use `api.justicesure.com`.

All Commerce API calls are server-to-server. Browser code calls the SOSO backend;
the SOSO backend calls JusticeSure.

---

## 3. Provisioning that the JusticeSure owner must complete

The API contract alone does not provision a merchant. Before integration testing,
the JusticeSure business owner must:

1. Enable the JusticeSure Online Store and ensure its link is active, not
   suspended and not archived.
2. Publish the intended products and variants for online sale.
3. Configure deliberate stock at the selected fulfilment locations.
4. Configure pickup and/or delivery rules, including the minimum order and
   delivery policy.
5. Connect the merchant's Paystack or Flutterwave account **inside JusticeSure**.
6. Confirm which provider SOSO will request: `paystack` or `flutterwave`.
7. Create a dedicated **staging** Commerce API key for SOSO.
8. Create a separate **production** Commerce API key only after staging acceptance.
9. Register SOSO's public HTTPS webhook URL in **Business → Integrations**.
10. Subscribe to `commerce.*` or all events listed in section 9.
11. Securely transfer the API key and webhook signing secret into SOSO's backend
    secret manager. They must not be sent in ordinary chat or committed to source.

Create/rotate staging and production credentials separately.

---

## 4. Required SOSO backend configuration

Use secret-manager placeholders such as:

```text
JUSTICESURE_COMMERCE_BASE_URL=https://justicesure.ai/api/v1/commerce
JUSTICESURE_COMMERCE_API_KEY=<dedicated jsk_ key; server-only>
JUSTICESURE_COMMERCE_WEBHOOK_SECRET=<secret returned at webhook creation/rotation>
SOSO_PAYMENT_RETURN_URL=https://<soso-domain>/<payment-return-path>
SOSO_JUSTICESURE_WEBHOOK_URL=https://<soso-domain>/<webhook-path>
STOREFRONT_DATABASE_URL=<durable database for orders and webhook event claims>
```

Never use `VITE_`, `NEXT_PUBLIC_`, `PUBLIC_` or another browser-exposed prefix for
the API key or webhook secret.

The JusticeSure API key must have only these scopes:

| Scope | Purpose |
| --- | --- |
| `commerce:catalog:read` | Store, locations, categories, products and availability |
| `commerce:orders:write` | Delivery quotes and order creation |
| `commerce:payments:initiate` | JusticeSure-managed hosted payment sessions |
| `commerce:orders:read` | Authoritative order, payment and fulfilment status |

Authentication header:

```http
Authorization: Bearer jsk_REDACTED
Accept: application/json
```

- Missing, invalid, revoked or expired key: `401`.
- Valid key without the required scope: `403`.
- Never expose or log the key.

---

## 5. Endpoint map

Paths below are relative to the Commerce API base URL.

| Method | Path | Scope |
| --- | --- | --- |
| `GET` | `/store` | `commerce:catalog:read` |
| `GET` | `/locations` | `commerce:catalog:read` |
| `GET` | `/categories` | `commerce:catalog:read` |
| `GET` | `/products` | `commerce:catalog:read` |
| `GET` | `/products/:productId` | `commerce:catalog:read` |
| `POST` | `/delivery-quotes` | `commerce:orders:write` |
| `POST` | `/orders` | `commerce:orders:write` |
| `POST` | `/orders/:orderId/payment-sessions` | `commerce:payments:initiate` |
| `GET` | `/orders/:orderId` | `commerce:orders:read` |

`GET /products` accepts `limit` (1–100), `offset`, `search`, `category` and an
owned `locationId`.

Every money value is integer kobo. For example:

```text
NGN 45,000.00 = 4500000
```

SOSO must never send or trust its own price as authority. JusticeSure recalculates
the cart, variant, availability, stock, delivery fee and final total.

---

## 6. Required idempotency and timeout behavior

`POST /orders` and `POST /orders/:orderId/payment-sessions` require:

```http
Idempotency-Key: checkout_01J_UNIQUE_OPERATION
```

Rules:

- 8–64 characters: letters, numbers, `_`, `.`, `:`, or `-`.
- Use a different key for order creation and payment-session creation.
- Persist each key before making the request.
- Retry a timed-out logical operation using the **same** key.
- Never reuse the key for a changed cart, customer, order or payment attempt.
- Use bounded request timeouts.
- For `429`, respect `Retry-After` and retry with the same key.
- Read `Idempotency-Replayed: true` on a successful replay.

---

## 7. Authoritative checkout flow

### Step 1 — Catalogue

Use `/store`, `/locations`, `/categories`, `/products` and
`/products/:productId`.

The product response is a customer-safe projection. Supplier cost, staff,
merchant bank details, internal tenant data and POS terminal data are not part of
the Commerce response.

### Step 2 — Delivery quote

For delivery orders, request a fresh quote:

```http
POST /delivery-quotes
Content-Type: application/json
```

```json
{
  "items": [
    {
      "productId": "PRODUCT_UUID",
      "variantId": "VARIANT_UUID",
      "quantity": 1
    }
  ],
  "address": "Customer delivery address",
  "locationId": "OPTIONAL_LOCATION_UUID"
}
```

Success:

```json
{
  "data": {
    "currency": "NGN",
    "cartSubtotalKobo": 4500000,
    "feeKobo": 250000,
    "distanceKm": 12.4,
    "quoteToken": "SIGNED_SHORT_LIVED_TOKEN",
    "expiresInSeconds": 600
  }
}
```

The quote binds the normalized address, cart/store and server-calculated amount.
Create the delivery order before it expires.

### Step 3 — Create the order

```http
POST /orders
Content-Type: application/json
Idempotency-Key: order_<unique-operation>
```

```json
{
  "customer": {
    "name": "Customer name",
    "email": "customer@example.com",
    "phone": "+234..."
  },
  "items": [
    {
      "productId": "PRODUCT_UUID",
      "variantId": "VARIANT_UUID",
      "quantity": 1
    }
  ],
  "fulfillment": {
    "type": "delivery",
    "locationId": "OPTIONAL_LOCATION_UUID",
    "address": "Customer delivery address",
    "deliveryQuoteToken": "SIGNED_QUOTE_TOKEN"
  },
  "paymentMethod": "paystack",
  "notes": "Optional customer note"
}
```

For pickup, use `type: "pickup"` and an owned, active, non-virtual `locationId`.

New order: `201`. Idempotent replay: `200` with the original order and
`Idempotency-Replayed: true`.

Persist the returned `data.id` as the JusticeSure order ID and bind it to the
authenticated SOSO customer. Never provide a general customer-facing endpoint
that accepts an arbitrary order ID without checking that local ownership.

### Step 4 — Create a JusticeSure-managed hosted payment session

The provider must match `paymentMethod` used when creating the order.

#### Paystack request

```http
POST /orders/:orderId/payment-sessions
Content-Type: application/json
Idempotency-Key: payment_<unique-operation>
```

```json
{
  "provider": "paystack",
  "email": "customer@example.com"
}
```

Paystack success response:

```json
{
  "data": {
    "provider": "paystack",
    "reference": "jsorder_<order-uuid>_<suffix>",
    "checkoutUrl": "https://provider-hosted-checkout/...",
    "accessCode": "provider-access-code"
  }
}
```

#### Flutterwave request

Flutterwave requires a public HTTPS return URL:

```json
{
  "provider": "flutterwave",
  "email": "customer@example.com",
  "redirectUrl": "https://<soso-domain>/<payment-return-path>"
}
```

Flutterwave success response:

```json
{
  "data": {
    "provider": "flutterwave",
    "reference": "jsfworder_<order-uuid>_<suffix>",
    "checkoutUrl": "https://provider-hosted-checkout/..."
  }
}
```

Persist the reference and `checkoutUrl` before returning the redirect to the
shopper. Redirect only to the exact HTTPS URL returned by JusticeSure.

An exact idempotent replay after initialization returns:

```json
{
  "data": {
    "provider": "paystack",
    "reference": "jsorder_<order-uuid>_<suffix>",
    "checkoutUrl": null,
    "status": "already_initialized"
  }
}
```

**Important current v1 recovery rule:** SOSO must persist the first successful
`checkoutUrl`. A replay proves that the same session was initialized but does not
return the hosted URL again. A different payment-session attempt for that order
returns `409 PAYMENT_SESSION_EXISTS`. If the first response is lost before SOSO
stores the URL, fail closed and show that the payment session could not be
recovered; do not create a paid order or guess a provider URL. JusticeSure must
close this recovery gap before final production certification.

Session creation does **not** mean payment succeeded.

### Step 5 — Payment return

The provider redirect is navigation only. It is not proof of payment.

On the SOSO return page:

1. Show “Checking payment status”.
2. Ask the authenticated SOSO backend for the customer-owned order.
3. The backend calls `GET /orders/:orderId`.
4. Show paid/processing only when JusticeSure reports a verified paid state.
5. If still pending, continue bounded polling or wait for the signed webhook.
6. Never let query parameters such as `status=success` mark the order paid.

---

## 8. Order, payment, refund and fulfilment rules

SOSO should display JusticeSure state, not create a parallel authoritative state.

Baseline flow:

```text
Order created
  -> payment pending / order new
  -> hosted session initialized (still unpaid)
  -> verified provider callback inside JusticeSure
  -> payment paid / order processing
  -> merchant fulfils in JusticeSure
  -> fulfilment/order completed
```

Rules:

- A redirect alone never moves payment to paid.
- Failed/abandoned provider checkout remains unpaid and is never fulfilled.
- SOSO cannot directly mark paid, cancel, refund or approve fulfilment through
  the Commerce API.
- Merchant cancellation/refund/fulfilment happens in JusticeSure and reaches SOSO
  through webhooks and `GET /orders/:orderId`.
- Full refunds display as refunded; partial refunds display as partially refunded.
- Never ship, grant access or otherwise fulfil from a browser callback alone.
- `GET /orders/:orderId` is the authoritative recovery/read model after webhook
  delays, retries or SOSO downtime.

---

## 9. JusticeSure → SOSO webhook contract

Subscribe to `commerce.*` or these individual events:

- `commerce.product.updated`
- `commerce.inventory.updated`
- `commerce.order.created`
- `commerce.order.updated`
- `commerce.payment.updated`
- `commerce.order.cancelled`
- `commerce.order.refunded`
- `commerce.fulfilment.updated`

Required headers:

```http
Content-Type: application/json
X-JusticeSure-Timestamp: <unix-seconds>
X-JusticeSure-Event-Id: evt_<unique-id>
X-JusticeSure-Event: commerce.payment.updated
X-JusticeSure-Signature: sha256=<64-lowercase-hex>
```

Envelope:

```json
{
  "id": "evt_<unique-id>",
  "event": "commerce.payment.updated",
  "apiVersion": "2025-01-01",
  "createdAt": "2026-08-22T12:00:00.000Z",
  "data": {
    "orderId": "ORDER_UUID",
    "orderNumber": "ORDER_NUMBER",
    "paymentStatus": "paid",
    "provider": "paystack",
    "amountKobo": 4750000,
    "updatedAt": "2026-08-22T12:00:00.000Z"
  }
}
```

Treat `data` as an event notification, not a replacement for the authoritative
resource:

- For order/payment/refund/fulfilment events, use `data.orderId`, enforce local
  customer ownership where applicable, and retrieve `GET /orders/:orderId`.
- For product/inventory events, refresh the affected product or catalogue.
- Ignore additional fields safely so new optional fields do not break delivery.
- Reject an unsupported `apiVersion` deliberately rather than misinterpreting it.

### Signature verification

Capture the **exact raw request bytes** before JSON parsing.

```text
signedMessage =
  X-JusticeSure-Timestamp
  + "."
  + X-JusticeSure-Event-Id
  + "."
  + rawRequestBody

expected =
  "sha256="
  + HMAC_SHA256_HEX(JUSTICESURE_COMMERCE_WEBHOOK_SECRET, signedMessage)
```

Requirements:

1. Validate the signature format.
2. Compare expected/received signatures in constant time.
3. Reject timestamps outside five minutes.
4. Confirm body `id` equals `X-JusticeSure-Event-Id`.
5. Confirm body `event` equals `X-JusticeSure-Event`.
6. Confirm the event type is supported.
7. Persist the event ID in a durable database before side effects.
8. Use a transactional/leased claim so crashed processing can be retried.
9. Return `2xx` only after processing is complete.
10. Return `2xx` for an already-completed duplicate without applying it again.
11. Return non-`2xx` (the reference receiver uses `503`) when processing failed,
    is unfinished, or another non-expired claim is still processing.

JusticeSure reuses the same event ID on retries. Delivery is bounded; handlers
should complete quickly and move slow work to a durable local queue.

Use the reference implementation in:

- `examples/headless-commerce-staging/webhook-receiver.ts`
- `examples/headless-commerce-staging/postgres-webhook-store.ts`

Do not deduplicate with an in-memory set.

---

## 10. Error handling

Normal business/API errors:

```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Human-readable explanation",
    "details": {}
  },
  "requestId": "request-correlation-id"
}
```

Authentication/scope errors may use:

```json
{
  "error": "Human-readable authorization error or INSUFFICIENT_SCOPE.",
  "code": "INSUFFICIENT_SCOPE",
  "requiredScope": "commerce:orders:write"
}
```

Log the `requestId`, HTTP status and safe error code. Do not log API keys,
webhook secrets, full customer payloads or provider checkout URLs.

Expected statuses include:

- `400`: malformed or missing required input/idempotency key.
- `401`: missing, invalid, revoked or expired API key.
- `403`: missing Commerce scope.
- `404`: resource not visible to this exact merchant key.
- `409`: already paid or a conflicting payment session exists.
- `422`: valid request cannot be fulfilled against current catalogue, stock,
  location, delivery or payment policy.
- `429`: rate-limited; respect `Retry-After`.

---

## 11. Staging acceptance matrix

Use a dedicated JusticeSure test business, sandbox merchant gateway, test
products and unique idempotency keys.

| Case | Required result |
| --- | --- |
| Server-only auth | Key absent from browser bundle, logs and source control |
| Missing key | `401` |
| Missing scope | `403` |
| Catalogue | Published sellable products appear |
| Hidden/raw material | Does not appear |
| Sold-out tracked item | Cannot oversell |
| Variant validation | Missing/foreign variant is rejected |
| Pickup | Only owned active non-virtual location accepted |
| Delivery | Fresh signed quote required; JusticeSure calculates fee |
| Order retry | Same order key returns same order; no duplicate |
| Payment retry | Same reference/status; no second gateway session |
| Payment authority | Redirect alone does not mark paid |
| Verified sandbox payment | JusticeSure reports paid and emits payment update |
| Customer privacy | Customer A cannot obtain Customer B's order through SOSO |
| Webhook tamper | Modified body/signature rejected |
| Webhook replay window | Stale timestamp rejected |
| Duplicate event | Side effects applied once |
| Receiver failure | Non-2xx causes visible retry; later retry processes once |
| Cancellation/refund | JusticeSure action appears correctly in SOSO |
| Fulfilment | JusticeSure tracking/status appears correctly in SOSO |
| Recovery | `GET /orders/:orderId` restores state after SOSO/webhook downtime |

Record the request IDs, JusticeSure order IDs, provider references and event IDs
for the staging evidence without recording secrets.

---

## 12. Production go-live gate

Do not enable real shopper payments until all items are true:

- Staging acceptance matrix has passed.
- Payment-session first-response recovery gap has been accepted or fixed.
- JusticeSure Online Store and intended products are production-ready.
- Merchant Paystack/Flutterwave connection is verified inside JusticeSure.
- Dedicated production Commerce key has only the four required scopes.
- Production webhook uses public HTTPS and has passed signature/retry tests.
- SOSO customer authentication and per-order authorization have been reviewed.
- API key and webhook secret are stored only in the production secret manager.
- Monitoring exists for API errors, pending orders and failed webhook processing.
- One low-value live smoke transaction has passed order, payment, webhook,
  fulfilment and receipt/reconciliation checks.
- Any staging credential copied outside its secret manager has been rotated.

SOSO should remain fail-closed until this gate passes: show that payment is
unavailable or unconfirmed rather than fabricating a checkout or paid order.

---

## 13. What must be transferred separately

This handoff intentionally contains no credentials. The JusticeSure owner or
operator must separately provision and securely transfer:

1. Dedicated SOSO staging `jsk_...` Commerce API key.
2. SOSO staging commerce webhook signing secret.
3. Confirmed payment provider name (`paystack` or `flutterwave`) and readiness.
4. Test business/product/location identifiers to use in staging.
5. Approved SOSO staging webhook and payment-return URLs.
6. Later, separate production key and webhook secret after staging acceptance.

Provider keys remain inside JusticeSure and are never transferred to SOSO.
